import React,  {useState,useEffect, useCallback, useMemo} from 'react';
import { StyleSheet, Text, View, TextInput, ActivityIndicator, SectionList, Alert, FlatList , RefreshControl} from 'react-native';
import {SafeAreaView, SafeAreaProvider } from 'react-native-safe-area-context';
import {Tour, groupByCity, formatDate, formatPrice, getSeatLabel} from './assets/tour'
import TourItem from './components/TourItem'
// or any files within the Snack

function HomeScreen(){
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);
  const [tours, setTours] = useState<Tour[]>([]);
  const [refresh, setRefresh] = useState(false);

const API_URL = 'https://6830a5f76205ab0d6c39ee1d.mockapi.io/tours';

  const loadTours= useCallback(async ()=>{
    try{
      const res =  await fetch(API_URL);
      const data =  await res.json();
      setTours(data);
    }catch(e){
      console.log(e);
    }
  }, [])

  useEffect(()=>{
      loadTours().finally(()=> setLoading(false));
  },[loadTours])

// kéo để làm mới 
const onRefresh = async () => {
  setRefresh(true);
  await loadTours();
  setRefresh(false);
}

// lọc và tìm kiếm 
const sections = useMemo(()=>{
  const keyword = search.trim().toLowerCase();
  const filterd = tours.filter((t)=> t.name.toLowerCase().includes(keyword));
  return groupByCity(filterd);
}, [tours, search]);

// yeeu thich 
const favorites = useMemo(()=>
  tours.filter((t)=> t.isFavorite)
, [tours])


const handlePress = useCallback((tour: Tour) => {
  Alert.alert(
    tour.name, 
    `Khởi hành: ${formatDate(tour.departure)}\nSố ngày: ${tour.days}\nGiá: ${formatPrice(tour.price)}`
  )
}, [])

// caapj nhatj 
const handleToggleFavorite  = useCallback(async (id: string, next: boolean)=>{
  setTours((prev)=> prev.map((t)=> t.id == id ?{...t, isFavorite: next}: t))
  try{
    const res = await fetch(`${API_URL}/${id}`,{
      method: 'PUT',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({isFavorite: next}),
    });
    if(!res.ok) throw new Error('PUT ERROR');

  }catch(e){
    console.log(e);
  }
}, [])



const renderFavorites = ()=>{
  <View>
    <Text> Tour yeu thich ({favorites.length}) </Text>

    {
      favorites.length === 0 ? (
        <Text> Khong co cai yeu thich nao </Text>
      ):(
        <FlatList
          data= {favorites}
          horizontal
          keyExtractor={(item)=> item.id}
          renderItem={({item})=> (
            <TourItem
              compact
              tour= {item}
              onPress={handlePress}
              onToggleFavorite={handleToggleFavorite}
            />
          )}
        />
      )
    }
  </View>
};

 return (
  <SafeAreaView style={{ flex: 1 }}>
    <View style={styles.header}>
      <Text style={styles.title}>Tour Việt</Text>

      <Text style={styles.student}>
        22674201 - Pham Van Hinh
      </Text>

      <TextInput
        value={search}
        onChangeText={setSearch}
        placeholder="Tìm tour theo tên..."
        style={styles.search}
      />
    </View>

    {loading ? (
      <ActivityIndicator size="large" />
    ) : (
      <SectionList
        sections={sections}
        keyExtractor={(item) => String(item.id)}
        stickySectionHeadersEnabled={true}
        ListHeaderComponent={renderFavorites}
        ListEmptyComponent={
          <Text>Không có giá trị</Text>
        }
        refreshControl={
          <RefreshControl
            refreshing={refresh}
            onRefresh={onRefresh}
          />
        }
        renderSectionHeader={({ section }) => (
          <Text>
            {section.title} - {section.data.length} tour
          </Text>
        )}
        renderItem={({ item }) => (
          <TourItem
            tour={item}
            onPress={handlePress}
            onToggleFavorite={handleToggleFavorite}
          />
        )}
      />
    )}
  </SafeAreaView>
);
}
export default function App() {
  return (
      <SafeAreaProvider>  
        <HomeScreen/>
      </SafeAreaProvider>
  );
}

const styles = StyleSheet.create({
  header:{
    padding: 16
  },
  title:{
    fontSize: 30, 
    fontWeight: 'bold'
  },
  student:{
    marginVertical: 16
  },
  search:{
    padding: 10,
    borderWidth: 1,
    borderRadius: 4, 
    borderColor: '#999'
  }, 
  sectionHeader: {
    fontSize: 16, 
    fontWeight: 'bold',
    padding: 16
  },
  item:{
    fontSize: 12,
    borderBottomWidth: 1, 
    borderColor: '#eee'
  }
});
