export type Tour = {
  id: string;
  name: string;
  city: string;
  days: number;
  price: number;
  seats: number;
  departure: string;
  image: string;
  isFavorite: boolean;
};

export function groupByCity(tours: Tour[]){
  const map : {[city: string]: Tour[]}= {};

  tours.forEach((tour)=>{
    if(!map[tour.city]){
      map[tour.city] = [];
    }
    map[tour.city].push(tour);
  })

  return Object.keys(map)
      .sort((a,b) => a.localeCompare(b))
      .map((city)=> ({
        title: city, 
        data: map[city].sort((a,b) => a.departure.localeCompare(b.departure))
      }));
}

export function formatDate(date: string){
  const [y, m, d] = date.split('-');
  return `${d}/${m}/${y}` ;
}

export function getSeatLabel(searts: number){
  if(searts == 0) return 'Hết Chỗ';
  if(searts <= 3) return `Chỉ còn ${searts} chỗ`;
  return `còn ${searts} chỗ `
}

export function formatPrice(price: number) {
  return price.toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.') + ' ₫';
}
