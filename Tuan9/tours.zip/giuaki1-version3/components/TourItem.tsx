import React, {useState, useEffect} from 'react'
import {View, Text, Image, TouchableOpacity, StyleSheet} from 'react-native'
import {formatDate, formatPrice, getSeatLabel} from '../assets/tour'
export type Tour = {
  id: string;
  name: string;
  city: string;
  days: number;
  price: number;
  seats: number;
  departure: string;
  image: string;
  isFavorite: boolean;
};

export type TourItemProps = {
  tour: Tour;
  compact?: boolean;
  onPress: (tour: Tour) => void;
  onToggleFavorite: (id: string, next: boolean) => void;
} 

function TourItem({tour, compact, onPress, onToggleFavorite} :TourItemProps ){
    const isLow = tour.seats <=3 // hết chỗ 
    return (
        <TouchableOpacity style={styles.card} onPress={()=> onPress(tour)}>
          {
            !compact && <Image source={{uri: tour.image}} style={styles.image} />
          }
          <View>
            <Text> {tour.name} </Text>
            <Text> {tour.city} </Text>
            <Text> {formatDate(tour.departure)} </Text>
            <Text> {formatPrice(tour.price)}</Text>
            <Text style= {{color: isLow ? 'red': 'black'}}> {getSeatLabel(tour.seats)}</Text>
          </View>

          <TouchableOpacity testID="fav-btn" onPress={()=> onToggleFavorite(tour.id, !tour.isFavorite)}>
            <Text style={styles.heart}> {tour.isFavorite? '♥' : '♡'} </Text>
          </TouchableOpacity>
        </TouchableOpacity>
    )
}

export default React.memo(TourItem);

const styles = StyleSheet.create({
  card: {
    flexDirection: 'row',
    padding: 12, 
    borderBottomWidth: 1, 
    borderColor: '#eee'
  },
  image: {
    width: 80, 
    height: 80, 
    borderRadius: 8, 
    marginRight: 12
  },
  info: { flex: 1 },
  name: { fontWeight: 'bold', marginBottom: 2 },
  price: { fontWeight: 'bold', marginVertical: 2 },
  heart: { fontSize: 28, color: 'red' },
})