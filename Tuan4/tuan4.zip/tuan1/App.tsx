import React from 'react';
import {
  Image,
  SafeAreaView,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';

// ============================================================
// BOOKSTORE - FLEXBOX PART 2
// Bài 6: Floating Cart Button
// Bài 7: Home Screen hoàn chỉnh
// Bài 8: Book Detail Screen
// Bài 9: Bottom Tab Bar
// Bài 10: Cart Screen
//
// Cách học: Mỗi màn hình là một component riêng.
// Để xem màn hình khác, đổi component ở export default phía cuối file.
// ============================================================

// -----------------------------
// 1. DỮ LIỆU MẪU
// -----------------------------

type Book = {
  id: string;
  title: string;
  author: string;
  price: number;
  cover: string;
  discount?: string;
  description: string;
};

type CartItem = Book & {
  quantity: number;
};

const books: Book[] = [
  {
    id: 'book-01',
    title: 'Clean Code',
    author: 'Robert C. Martin',
    price: 250000,
    cover:
      'https://images.unsplash.com/photo-1544947950-fa07a98d237f?w=600&auto=format&fit=crop&q=80',
    discount: '-20%',
    description:
      'Cuốn sách trình bày các nguyên tắc viết mã nguồn rõ ràng, dễ đọc và dễ bảo trì. Đây là tài liệu tham khảo hữu ích cho lập trình viên muốn cải thiện chất lượng code.',
  },
  {
    id: 'book-02',
    title: 'The Pragmatic Programmer',
    author: 'David Thomas, Andrew Hunt',
    price: 320000,
    cover:
      'https://images.unsplash.com/photo-1512820790803-83ca734da794?w=600&auto=format&fit=crop&q=80',
    discount: 'Mới',
    description:
      'Sách chia sẻ những kinh nghiệm thực tế trong quá trình phát triển phần mềm, cách tư duy, giải quyết vấn đề và xây dựng thói quen làm việc hiệu quả.',
  },
  {
    id: 'book-03',
    title: 'Design Patterns',
    author: 'Erich Gamma và cộng sự',
    price: 350000,
    cover:
      'https://images.unsplash.com/photo-1532012197267-da84d127e765?w=600&auto=format&fit=crop&q=80',
    description:
      'Tìm hiểu các mẫu thiết kế phần mềm phổ biến và cách áp dụng chúng để giải quyết những vấn đề thường gặp trong thiết kế hướng đối tượng.',
  },
  {
    id: 'book-04',
    title: 'You Don’t Know JS Yet',
    author: 'Kyle Simpson',
    price: 280000,
    cover:
      'https://images.unsplash.com/photo-1519682337058-a94d519337bc?w=600&auto=format&fit=crop&q=80',
    discount: '-10%',
    description:
      'Một tài liệu giúp người học hiểu sâu hơn về JavaScript, từ những khái niệm nền tảng đến cách ngôn ngữ vận hành.',
  },
];

const cartItems: CartItem[] = [
  { ...books[0], quantity: 1 },
  { ...books[1], quantity: 2 },
  { ...books[2], quantity: 1 },
];

const categories = [
  'Tất cả',
  'Văn học',
  'Công nghệ',
  'Kinh tế',
  'Thiếu nhi',
  'Kỹ năng sống',
  'Truyện tranh',
];

const formatPrice = (price: number): string =>
  `${price.toLocaleString('vi-VN')}đ`;

// -----------------------------
// 2. CÁC COMPONENT DÙNG CHUNG
// -----------------------------

function AppHeader() {
  return (
    <View style={styles.header}>
      <View style={styles.headerBrand}>
        <Text style={styles.headerLogo}>📚</Text>
        <Text style={styles.headerTitle}>BookStore</Text>
      </View>

      <View style={styles.headerActions}>
        <Text style={styles.headerAction}>🔍</Text>
        <Text style={styles.headerAction}>🛒</Text>
      </View>
    </View>
  );
}

function CategoryChips() {
  return (
    <View style={styles.categorySection}>
      <Text style={styles.sectionTitle}>Danh mục sách</Text>
      <View style={styles.categoryList}>
        {categories.map((category, index) => (
          <View
            key={category}
            style={[
              styles.categoryChip,
              index === 0 && styles.categoryChipActive,
            ]}
          >
            <Text
              style={[
                styles.categoryText,
                index === 0 && styles.categoryTextActive,
              ]}
            >
              {category}
            </Text>
          </View>
        ))}
      </View>
    </View>
  );
}

function BookGridCard({ book }: { book: Book }) {
  return (
    <View style={styles.gridCard}>
      {/* View cha relative để badge absolute định vị theo ảnh bìa */}
      <View style={styles.gridImageContainer}>
        <Image source={{ uri: book.cover }} style={styles.gridCover} />
        {book.discount ? (
          <View style={styles.discountBadge}>
            <Text style={styles.discountText}>{book.discount}</Text>
          </View>
        ) : null}
      </View>

      <Text style={styles.gridBookTitle} numberOfLines={2}>
        {book.title}
      </Text>
      <Text style={styles.gridAuthor} numberOfLines={1}>
        {book.author}
      </Text>
      <Text style={styles.gridPrice}>{formatPrice(book.price)}</Text>
    </View>
  );
}

function BookGrid() {
  return (
    <View style={styles.bookGridSection}>
      <View style={styles.sectionHeadingRow}>
        <Text style={styles.sectionTitle}>Sách nổi bật</Text>
        <Text style={styles.seeAllText}>Xem tất cả</Text>
      </View>

      <View style={styles.bookGrid}>
        {books.map(book => (
          <BookGridCard key={book.id} book={book} />
        ))}
      </View>
    </View>
  );
}

// ============================================================
// BÀI 6 - FLOATING CART BUTTON
// Badge số lượng được absolute bên trong nút tròn.
// ============================================================

export function FloatingCartButton({
  itemCount = 4,
}: {
  itemCount?: number;
}) {
  return (
    <View style={styles.floatingCart}>
      <Text style={styles.floatingCartIcon}>🛒</Text>

      {/* Badge định vị theo nút giỏ hàng, không định vị theo màn hình */}
      <View style={styles.cartCountBadge}>
        <Text style={styles.cartCountText}>{itemCount}</Text>
      </View>
    </View>
  );
}

// ============================================================
// BÀI 7 - HOME SCREEN
// Header cố định + ScrollView + nút giỏ hàng nổi + tab bar.
// ============================================================

export function HomeScreen() {
  return (
    <SafeAreaView style={styles.screen}>
      <View style={styles.screenContent}>
        {/* Header nằm ngoài ScrollView nên không cuộn */}
        <AppHeader />

        <ScrollView
          style={styles.flexOne}
          contentContainerStyle={styles.homeScrollContent}
          showsVerticalScrollIndicator={false}
        >
          <View style={styles.welcomeBanner}>
            <Text style={styles.welcomeTitle}>Khám phá tri thức</Text>
            <Text style={styles.welcomeSubtitle}>
              Tìm cuốn sách phù hợp với bạn hôm nay.
            </Text>
          </View>

          <CategoryChips />
          <BookGrid />
        </ScrollView>

        {/* Nút nổi là sibling của ScrollView nên không cuộn theo nội dung */}
        <FloatingCartButton itemCount={4} />

        {/* Tab bar cố định bên dưới */}
        <BottomTabBar activeTab="home" />
      </View>
    </SafeAreaView>
  );
}

// ============================================================
// BÀI 8 - BOOK DETAIL SCREEN
// Nội dung chi tiết cuộn được, thanh mua hàng cố định bên dưới.
// ============================================================

export function BookDetailScreen() {
  const book = books[0];

  return (
    <SafeAreaView style={styles.screen}>
      <View style={styles.screenContent}>
        <View style={styles.simpleTopBar}>
          <Text style={styles.backText}>‹  Quay lại</Text>
          <Text style={styles.simpleTopBarTitle}>Chi tiết sách</Text>
          <Text style={styles.topBarCart}>🛒</Text>
        </View>

        <ScrollView
          style={styles.flexOne}
          contentContainerStyle={styles.detailScrollContent}
          showsVerticalScrollIndicator={false}
        >
          <Image source={{ uri: book.cover }} style={styles.detailCover} />

          <Text style={styles.detailTitle}>{book.title}</Text>
          <Text style={styles.detailAuthor}>Tác giả: {book.author}</Text>
          <Text style={styles.detailPrice}>{formatPrice(book.price)}</Text>

          <View style={styles.detailDivider} />

          <Text style={styles.detailSectionTitle}>Mô tả sách</Text>
          <Text style={styles.detailDescription}>{book.description}</Text>
          <Text style={styles.detailDescription}>{book.description}</Text>
          <Text style={styles.detailDescription}>{book.description}</Text>

          <View style={styles.detailInfoBox}>
            <Text style={styles.detailInfoTitle}>Thông tin sản phẩm</Text>
            <Text style={styles.detailInfoText}>Mã sách: {book.id}</Text>
            <Text style={styles.detailInfoText}>Tình trạng: Còn hàng</Text>
            <Text style={styles.detailInfoText}>Hình thức: Bìa mềm</Text>
          </View>
        </ScrollView>

        {/* Footer nằm ngoài ScrollView nên luôn ở cuối vùng nội dung */}
        <View style={styles.purchaseBar}>
          <View style={styles.purchasePriceBox}>
            <Text style={styles.purchaseLabel}>Giá bán</Text>
            <Text style={styles.purchasePrice}>{formatPrice(book.price)}</Text>
          </View>
          <View style={styles.addToCartButton}>
            <Text style={styles.addToCartText}>＋ Thêm vào giỏ</Text>
          </View>
        </View>
      </View>
    </SafeAreaView>
  );
}

// ============================================================
// BÀI 9 - BOTTOM TAB BAR
// Tab bar tĩnh, mỗi tab flex: 1 để chia đều chiều rộng.
// ============================================================

type TabKey = 'home' | 'categories' | 'cart' | 'account';

type BottomTabBarProps = {
  activeTab?: TabKey;
};

export function BottomTabBar({
  activeTab = 'home',
}: BottomTabBarProps) {
  const tabs: { key: TabKey; icon: string; label: string }[] = [
    { key: 'home', icon: '🏠', label: 'Trang chủ' },
    { key: 'categories', icon: '📚', label: 'Danh mục' },
    { key: 'cart', icon: '🛒', label: 'Giỏ hàng' },
    { key: 'account', icon: '👤', label: 'Tài khoản' },
  ];

  return (
    <View style={styles.tabBar}>
      {tabs.map(tab => {
        const selected = tab.key === activeTab;

        return (
          <View key={tab.key} style={styles.tabItem}>
            <Text style={[styles.tabIcon, selected && styles.activeTabText]}>
              {tab.icon}
            </Text>
            <Text
              style={[
                styles.tabLabel,
                selected && styles.activeTabText,
              ]}
            >
              {tab.label}
            </Text>
          </View>
        );
      })}
    </View>
  );
}

// ============================================================
// BÀI 10 - CART SCREEN
// ScrollView ở giữa; tổng tiền cố định; tab bar cố định dưới đáy.
// ============================================================

function CartItemRow({ item }: { item: CartItem }) {
  return (
    <View style={styles.cartItemRow}>
      <Image source={{ uri: item.cover }} style={styles.cartItemImage} />

      <View style={styles.cartItemInfo}>
        <Text style={styles.cartItemTitle} numberOfLines={2}>
          {item.title}
        </Text>
        <Text style={styles.cartItemAuthor} numberOfLines={1}>
          {item.author}
        </Text>
        <Text style={styles.cartItemPrice}>{formatPrice(item.price)}</Text>
      </View>

      <View style={styles.quantityBox}>
        <Text style={styles.quantityText}>x{item.quantity}</Text>
      </View>
    </View>
  );
}

export function CartScreen() {
  const total = cartItems.reduce(
    (sum, item) => sum + item.price * item.quantity,
    0,
  );

  return (
    <SafeAreaView style={styles.screen}>
      <View style={styles.screenContent}>
        <View style={styles.cartHeader}>
          <Text style={styles.cartHeaderTitle}>Giỏ hàng</Text>
          <Text style={styles.cartHeaderCount}>
            {cartItems.length} sản phẩm
          </Text>
        </View>

        {/* Chỉ danh sách sản phẩm được phép cuộn */}
        <ScrollView
          style={styles.flexOne}
          contentContainerStyle={styles.cartListContent}
          showsVerticalScrollIndicator={false}
        >
          {cartItems.map(item => (
            <CartItemRow key={item.id} item={item} />
          ))}
        </ScrollView>

        {/* Khu vực tổng tiền cố định, không nằm trong ScrollView */}
        <View style={styles.cartSummary}>
          <View style={styles.summaryRow}>
            <Text style={styles.summaryLabel}>Tạm tính</Text>
            <Text style={styles.summaryValue}>{formatPrice(total)}</Text>
          </View>
          <View style={styles.summaryRow}>
            <Text style={styles.summaryLabel}>Phí vận chuyển</Text>
            <Text style={styles.summaryValue}>Miễn phí</Text>
          </View>
          <View style={[styles.summaryRow, styles.totalRow]}>
            <Text style={styles.totalLabel}>Tổng cộng</Text>
            <Text style={styles.totalValue}>{formatPrice(total)}</Text>
          </View>

          <View style={styles.checkoutButton}>
            <Text style={styles.checkoutButtonText}>Thanh toán</Text>
          </View>
        </View>

        {/* Tab bar là vùng cố định thứ ba */}
        <BottomTabBar activeTab="cart" />
      </View>
    </SafeAreaView>
  );
}

// ============================================================
// STYLESHEET
// ============================================================

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: '#F5F6FA',
  },
  screenContent: {
    flex: 1,
    position: 'relative',
  },
  flexOne: {
    flex: 1,
  },

  // Header
  header: {
    height: 58,
    paddingHorizontal: 16,
    backgroundColor: '#202A5A',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  headerBrand: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  headerLogo: {
    fontSize: 23,
    marginRight: 8,
  },
  headerTitle: {
    color: '#FFFFFF',
    fontSize: 20,
    fontWeight: 'bold',
  },
  headerActions: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  headerAction: {
    color: '#FFFFFF',
    fontSize: 21,
    marginLeft: 18,
  },

  // Home scroll content
  homeScrollContent: {
    padding: 16,
    paddingBottom: 120,
  },
  welcomeBanner: {
    padding: 18,
    borderRadius: 14,
    backgroundColor: '#E4E9FF',
    marginBottom: 20,
  },
  welcomeTitle: {
    color: '#202A5A',
    fontSize: 20,
    fontWeight: 'bold',
  },
  welcomeSubtitle: {
    color: '#59627F',
    fontSize: 13,
    marginTop: 6,
  },
  sectionTitle: {
    color: '#20243A',
    fontSize: 17,
    fontWeight: 'bold',
  },
  sectionHeadingRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  seeAllText: {
    color: '#4656B8',
    fontSize: 13,
    fontWeight: '600',
  },

  // Category chips
  categorySection: {
    marginBottom: 22,
  },
  categoryList: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    alignContent: 'flex-start',
    marginTop: 10,
  },
  categoryChip: {
    paddingHorizontal: 13,
    paddingVertical: 8,
    borderWidth: 1,
    borderColor: '#AAB3E8',
    borderRadius: 20,
    backgroundColor: '#FFFFFF',
    marginRight: 8,
    marginBottom: 8,
  },
  categoryChipActive: {
    backgroundColor: '#4656B8',
    borderColor: '#4656B8',
  },
  categoryText: {
    color: '#465078',
    fontSize: 12,
  },
  categoryTextActive: {
    color: '#FFFFFF',
    fontWeight: 'bold',
  },

  // Book grid
  bookGridSection: {
    marginBottom: 16,
  },
  bookGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  gridCard: {
    width: '48%',
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 9,
    marginBottom: 14,
    borderWidth: 1,
    borderColor: '#E8EAF2',
  },
  gridImageContainer: {
    width: '100%',
    aspectRatio: 3 / 4,
    position: 'relative',
    borderRadius: 8,
    overflow: 'hidden',
    backgroundColor: '#E9EAF0',
  },
  gridCover: {
    width: '100%',
    height: '100%',
  },
  discountBadge: {
    position: 'absolute',
    top: 7,
    left: 7,
    paddingHorizontal: 7,
    paddingVertical: 4,
    backgroundColor: '#E74747',
    borderRadius: 5,
  },
  discountText: {
    color: '#FFFFFF',
    fontSize: 10,
    fontWeight: 'bold',
  },
  gridBookTitle: {
    color: '#20243A',
    fontSize: 13,
    fontWeight: 'bold',
    marginTop: 9,
    minHeight: 34,
  },
  gridAuthor: {
    color: '#777D91',
    fontSize: 11,
    marginTop: 3,
  },
  gridPrice: {
    color: '#D64242',
    fontSize: 13,
    fontWeight: 'bold',
    marginTop: 7,
  },

  // Floating cart button
  floatingCart: {
    position: 'absolute',
    right: 18,
    bottom: 86,
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: '#4656B8',
    justifyContent: 'center',
    alignItems: 'center',
    elevation: 6,
    zIndex: 5,
  },
  floatingCartIcon: {
    fontSize: 24,
  },
  cartCountBadge: {
    position: 'absolute',
    top: -3,
    right: -3,
    minWidth: 21,
    height: 21,
    paddingHorizontal: 5,
    borderRadius: 11,
    backgroundColor: '#F04444',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: '#FFFFFF',
  },
  cartCountText: {
    color: '#FFFFFF',
    fontSize: 10,
    fontWeight: 'bold',
  },

  // Top bar used by detail screen
  simpleTopBar: {
    height: 54,
    paddingHorizontal: 16,
    backgroundColor: '#FFFFFF',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderBottomWidth: 1,
    borderBottomColor: '#ECEEF4',
  },
  backText: {
    color: '#4656B8',
    fontSize: 14,
    width: 95,
  },
  simpleTopBarTitle: {
    color: '#20243A',
    fontSize: 16,
    fontWeight: 'bold',
  },
  topBarCart: {
    width: 95,
    textAlign: 'right',
    fontSize: 19,
  },

  // Book detail
  detailScrollContent: {
    padding: 18,
    paddingBottom: 24,
  },
  detailCover: {
    width: 190,
    aspectRatio: 3 / 4,
    alignSelf: 'center',
    borderRadius: 12,
    backgroundColor: '#E9EAF0',
    marginBottom: 20,
  },
  detailTitle: {
    color: '#20243A',
    fontSize: 23,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  detailAuthor: {
    color: '#777D91',
    fontSize: 14,
    textAlign: 'center',
    marginTop: 8,
  },
  detailPrice: {
    color: '#D64242',
    fontSize: 21,
    fontWeight: 'bold',
    textAlign: 'center',
    marginTop: 12,
  },
  detailDivider: {
    height: 1,
    backgroundColor: '#E2E4EC',
    marginVertical: 20,
  },
  detailSectionTitle: {
    color: '#20243A',
    fontSize: 17,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  detailDescription: {
    color: '#555B6E',
    fontSize: 14,
    lineHeight: 23,
    marginBottom: 12,
    textAlign: 'justify',
  },
  detailInfoBox: {
    backgroundColor: '#FFFFFF',
    borderRadius: 10,
    padding: 14,
    marginTop: 8,
  },
  detailInfoTitle: {
    color: '#20243A',
    fontSize: 15,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  detailInfoText: {
    color: '#646A7B',
    fontSize: 13,
    marginTop: 5,
  },
  purchaseBar: {
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: '#FFFFFF',
    borderTopWidth: 1,
    borderTopColor: '#E8EAF0',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  purchasePriceBox: {
    flex: 1,
  },
  purchaseLabel: {
    color: '#858A9A',
    fontSize: 11,
  },
  purchasePrice: {
    color: '#D64242',
    fontSize: 17,
    fontWeight: 'bold',
    marginTop: 4,
  },
  addToCartButton: {
    paddingHorizontal: 18,
    paddingVertical: 13,
    borderRadius: 9,
    backgroundColor: '#4656B8',
  },
  addToCartText: {
    color: '#FFFFFF',
    fontWeight: 'bold',
    fontSize: 13,
  },

  // Bottom tab bar
  tabBar: {
    minHeight: 62,
    paddingTop: 8,
    paddingBottom: 5,
    backgroundColor: '#FFFFFF',
    borderTopWidth: 1,
    borderTopColor: '#E8EAF0',
    flexDirection: 'row',
  },
  tabItem: {
    flex: 1,
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
  },
  tabIcon: {
    fontSize: 18,
    color: '#8C91A3',
  },
  tabLabel: {
    color: '#8C91A3',
    fontSize: 10,
    marginTop: 3,
  },
  activeTabText: {
    color: '#4656B8',
    fontWeight: 'bold',
  },

  // Cart screen
  cartHeader: {
    minHeight: 58,
    backgroundColor: '#FFFFFF',
    paddingHorizontal: 16,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderBottomWidth: 1,
    borderBottomColor: '#ECEEF4',
  },
  cartHeaderTitle: {
    color: '#20243A',
    fontSize: 19,
    fontWeight: 'bold',
  },
  cartHeaderCount: {
    color: '#858A9A',
    fontSize: 12,
  },
  cartListContent: {
    padding: 14,
    paddingBottom: 20,
  },
  cartItemRow: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    padding: 10,
    borderRadius: 10,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: '#ECEEF4',
  },
  cartItemImage: {
    width: 62,
    height: 82,
    borderRadius: 6,
    backgroundColor: '#E9EAF0',
  },
  cartItemInfo: {
    flex: 1,
    marginLeft: 11,
    marginRight: 8,
  },
  cartItemTitle: {
    color: '#20243A',
    fontSize: 13,
    fontWeight: 'bold',
  },
  cartItemAuthor: {
    color: '#858A9A',
    fontSize: 11,
    marginTop: 5,
  },
  cartItemPrice: {
    color: '#D64242',
    fontSize: 12,
    fontWeight: 'bold',
    marginTop: 8,
  },
  quantityBox: {
    width: 42,
    paddingVertical: 7,
    borderRadius: 6,
    backgroundColor: '#EEF0FA',
    alignItems: 'center',
  },
  quantityText: {
    color: '#4656B8',
    fontSize: 12,
    fontWeight: 'bold',
  },
  cartSummary: {
    backgroundColor: '#FFFFFF',
    paddingHorizontal: 16,
    paddingTop: 12,
    paddingBottom: 14,
    borderTopWidth: 1,
    borderTopColor: '#E8EAF0',
  },
  summaryRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  summaryLabel: {
    color: '#777D91',
    fontSize: 12,
  },
  summaryValue: {
    color: '#42475A',
    fontSize: 12,
  },
  totalRow: {
    paddingTop: 9,
    borderTopWidth: 1,
    borderTopColor: '#ECEEF4',
    marginTop: 2,
  },
  totalLabel: {
    color: '#20243A',
    fontSize: 15,
    fontWeight: 'bold',
  },
  totalValue: {
    color: '#D64242',
    fontSize: 17,
    fontWeight: 'bold',
  },
  checkoutButton: {
    backgroundColor: '#4656B8',
    paddingVertical: 13,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 9,
    marginTop: 5,
  },
  checkoutButtonText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: 'bold',
  },
});

// ============================================================
// MẶC ĐỊNH HIỂN THỊ HOME SCREEN
// Thử đổi thành BookDetailScreen hoặc CartScreen để xem màn hình khác.
// ============================================================

export default HomeScreen;
