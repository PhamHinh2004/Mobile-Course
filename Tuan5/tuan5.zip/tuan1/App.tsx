import React, { useState, useEffect } from 'react';
import {
  SafeAreaView,
  View,
  Text,
  Image,
  TouchableOpacity,
  StyleSheet,
  StatusBar,
} from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import {
  createNativeStackNavigator,
  NativeStackScreenProps,
} from '@react-navigation/native-stack';

// --- CẤU HÌNH DỮ LIỆU MÀU SẮC & HÌNH ẢNH ---
export interface ColorOption {
  id: string;
  name: string;
  colorCode: string;
  image: { uri: string };
}

const COLORS_DATA: ColorOption[] = [
  {
    id: 'silver',
    name: 'bạc',
    colorCode: '#C5F1FB',
    image: {
      uri: 'https://cdn.tgdd.vn/Products/Images/42/214909/vsmart-joy-3-trang-400x460-400x460.png',
    },
  },
  {
    id: 'red',
    name: 'đỏ',
    colorCode: '#F30D0D',
    image: {
      uri: 'https://cdn.tgdd.vn/Products/Images/42/214909/vsmart-joy-3-do-400x460-400x460.png',
    },
  },
  {
    id: 'black',
    name: 'đen',
    colorCode: '#000000',
    image: {
      uri: 'https://cdn.tgdd.vn/Products/Images/42/214909/vsmart-joy-3-den-400x460-400x460.png',
    },
  },
  {
    id: 'blue',
    name: 'xanh',
    colorCode: '#234896',
    image: {
      uri: 'https://cdn.tgdd.vn/Products/Images/42/214909/vsmart-joy-3-xanh-400x460-400x460.png',
    },
  },
];

// --- ĐỊNH NGHĨA PARAMS CHO STACK ---
type RootStackParamList = {
  Product: { selectedColor?: ColorOption } | undefined;
  ColorPicker: { currentColor: ColorOption };
};

type ProductProps = NativeStackScreenProps<RootStackParamList, 'Product'>;
type ColorPickerProps = NativeStackScreenProps<RootStackParamList, 'ColorPicker'>;

const Stack = createNativeStackNavigator<RootStackParamList>();

// ==========================================
// MÀN HÌNH 1: CHI TIẾT SẢN PHẨM (Screen 01 & 04)
// ==========================================
function ProductScreen({ navigation, route }: ProductProps) {
  const [currentColor, setCurrentColor] = useState<ColorOption>(COLORS_DATA[3]); // Mặc định màu xanh

  // Nhận tham số truyền ngược về từ ColorScreen
  useEffect(() => {
    if (route.params?.selectedColor) {
      setCurrentColor(route.params.selectedColor);
    }
  }, [route.params?.selectedColor]);

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.imageContainer}>
        <Image
          source={currentColor.image}
          style={styles.mainImage}
          resizeMode="contain"
        />
      </View>

      <View style={styles.detailsContainer}>
        <Text style={styles.productTitle}>
          Điện Thoại Vsmart Joy 3 - Hàng chính hãng
        </Text>

        {/* Rating */}
        <View style={styles.ratingRow}>
          <Text style={styles.stars}>★★★★★</Text>
          <Text style={styles.ratingCount}>(Xem 828 đánh giá)</Text>
        </View>

        {/* Price */}
        <View style={styles.priceRow}>
          <Text style={styles.currentPrice}>1.790.000 đ</Text>
          <Text style={styles.oldPrice}>1.790.000 đ</Text>
        </View>

        <Text style={styles.refundNotice}>Ở ĐÂU RẺ HƠN HOÀN TIỀN ⓘ</Text>

        {/* Nút chuyển sang màn hình chọn màu */}
        <TouchableOpacity
          style={styles.selectColorButton}
          activeOpacity={0.8}
          onPress={() =>
            navigation.navigate('ColorPicker', { currentColor })
          }
        >
          <Text style={styles.selectColorText}>
            4 MÀU CHỌN MÀU (Hiện tại: {currentColor.name.toUpperCase()})
          </Text>
          <Text style={styles.arrowIcon}>›</Text>
        </TouchableOpacity>
      </View>

      {/* Button Mua */}
      <View style={styles.bottomBar}>
        <TouchableOpacity style={styles.buyButton} activeOpacity={0.85}>
          <Text style={styles.buyButtonText}>CHỌN MUA</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

// ==========================================
// MÀN HÌNH 2: CHỌN MÀU (Screen 2 & 03)
// ==========================================
function ColorScreen({ navigation, route }: ColorPickerProps) {
  // Lấy màu hiện tại từ route param
  const [selectedColor, setSelectedColor] = useState<ColorOption>(
    route.params?.currentColor || COLORS_DATA[0]
  );

  // Truyền ngược màu đã chọn về màn hình Product
  const handleDone = () => {
    navigation.navigate('Product', { selectedColor });
  };

  return (
    <SafeAreaView style={styles.container}>
      {/* Header tóm tắt sản phẩm đang chọn */}
      <View style={styles.pickerHeader}>
        <Image
          source={selectedColor.image}
          style={styles.pickerPreviewImage}
          resizeMode="contain"
        />
        <View style={styles.pickerHeaderInfo}>
          <Text style={styles.pickerProductTitle}>
            Điện Thoại Vsmart Joy 3{'\n'}Hàng chính hãng
          </Text>
          <Text style={styles.pickerMetaText}>
            Màu: <Text style={styles.boldText}>{selectedColor.name}</Text>
          </Text>
          <Text style={styles.pickerMetaText}>
            Cung cấp bởi: <Text style={styles.boldText}>Tiki Trading</Text>
          </Text>
          <Text style={styles.pickerPriceText}>1.790.000 đ</Text>
        </View>
      </View>

      {/* Vùng chọn màu */}
      <View style={styles.pickerBody}>
        <Text style={styles.pickerInstructionText}>Chọn một màu bên dưới:</Text>

        <View style={styles.colorPalette}>
          {COLORS_DATA.map((item) => {
            const isSelected = selectedColor.id === item.id;
            return (
              <TouchableOpacity
                key={item.id}
                style={[
                  styles.colorSquare,
                  { backgroundColor: item.colorCode },
                  isSelected && styles.selectedColorSquare,
                ]}
                activeOpacity={0.7}
                onPress={() => setSelectedColor(item)}
              />
            );
          })}
        </View>

        {/* Nút Xong -> Quay về và cập nhật màn trước */}
        <TouchableOpacity
          style={styles.doneButton}
          activeOpacity={0.85}
          onPress={handleDone}
        >
          <Text style={styles.doneButtonText}>XONG</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

// ==========================================
// COMPONENT CHÍNH (NAVIGATION CONTAINER)
// ==========================================
export default function App() {
  return (
    <NavigationContainer>
      <StatusBar barStyle="dark-content" />
      <Stack.Navigator
        initialRouteName="Product"
        screenOptions={{ headerShown: false }}
      >
        <Stack.Screen name="Product" component={ProductScreen} />
        <Stack.Screen name="ColorPicker" component={ColorScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

// ==========================================
// STYLES
// ==========================================
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
  imageContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
    height: 320,
  },
  mainImage: {
    width: '75%',
    height: '100%',
  },
  detailsContainer: {
    paddingHorizontal: 20,
    flex: 1,
  },
  productTitle: {
    fontSize: 15,
    fontWeight: '500',
    color: '#000000',
    marginBottom: 8,
  },
  ratingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  stars: {
    color: '#E0A800',
    fontSize: 16,
    letterSpacing: 2,
    marginRight: 14,
  },
  ratingCount: {
    fontSize: 13,
    color: '#333333',
  },
  priceRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  currentPrice: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#000000',
    marginRight: 20,
  },
  oldPrice: {
    fontSize: 14,
    color: '#808080',
    textDecorationLine: 'line-through',
  },
  refundNotice: {
    color: '#EE0A0A',
    fontWeight: '700',
    fontSize: 11,
    marginBottom: 16,
  },
  selectColorButton: {
    borderWidth: 1,
    borderColor: '#C4C4C4',
    borderRadius: 8,
    paddingVertical: 10,
    paddingHorizontal: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: '#FAFAFA',
  },
  selectColorText: {
    fontSize: 13,
    fontWeight: '600',
    color: '#000000',
  },
  arrowIcon: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#555555',
  },
  bottomBar: {
    padding: 20,
  },
  buyButton: {
    backgroundColor: '#EE0A0A',
    borderRadius: 8,
    paddingVertical: 14,
    alignItems: 'center',
    justifyContent: 'center',
  },
  buyButtonText: {
    color: '#FFFFFF',
    fontWeight: 'bold',
    fontSize: 16,
  },
  // Color Screen Styles
  pickerHeader: {
    flexDirection: 'row',
    padding: 16,
    backgroundColor: '#FFFFFF',
  },
  pickerPreviewImage: {
    width: 100,
    height: 120,
    marginRight: 12,
  },
  pickerHeaderInfo: {
    flex: 1,
    justifyContent: 'space-between',
  },
  pickerProductTitle: {
    fontSize: 14,
    color: '#000000',
    lineHeight: 18,
  },
  pickerMetaText: {
    fontSize: 13,
    color: '#333333',
    marginTop: 2,
  },
  boldText: {
    fontWeight: 'bold',
    color: '#000000',
  },
  pickerPriceText: {
    fontSize: 15,
    fontWeight: 'bold',
    color: '#000000',
    marginTop: 4,
  },
  pickerBody: {
    flex: 1,
    backgroundColor: '#C4C4C4',
    padding: 16,
    justifyContent: 'space-between',
  },
  pickerInstructionText: {
    fontSize: 15,
    color: '#000000',
    marginBottom: 12,
  },
  colorPalette: {
    alignItems: 'center',
    gap: 12,
  },
  colorSquare: {
    width: 72,
    height: 72,
    borderRadius: 4,
  },
  selectedColorSquare: {
    borderWidth: 3,
    borderColor: '#FFFFFF',
    transform: [{ scale: 1.05 }],
  },
  doneButton: {
    backgroundColor: '#1952E6',
    borderRadius: 8,
    paddingVertical: 14,
    alignItems: 'center',
    marginTop: 16,
  },
  doneButtonText: {
    color: '#FFFFFF',
    fontWeight: 'bold',
    fontSize: 18,
  },
});