import {
  StyleSheet,
  Text,
  View,
  TextInput,
  FlatList,
  TouchableOpacity,
  Alert,
  ActivityIndicator,
  Image,
} from 'react-native';
import React, { useState, useEffect, useMemo, useCallback } from 'react';

export type Movie = {
  id: string;
  title: string;
  genre: string;
  year: number;
  rating: number;
  poster: string;
  isShowing: boolean;
};

export type MovieProps = {
  movie: Movie;
  layout?: 'row' | 'tile';
  onSelect: (id: string) => void;
};

function MovieCard({ movie, layout = 'tile', onSelect }: MovieProps) {
  const isTile = layout === 'tile';
  const ratingText = `⭐ ${movie.rating.toFixed(1)}`;

  return (
    <TouchableOpacity
      style={[styles.card, isTile && styles.cardTile]}
      onPress={() => onSelect(movie.id)}>
      <View>
        <Image
          source={{ uri: movie.poster }}
          style={isTile ? styles.imageTile : styles.imageRow}
        />
        {isTile && <Text style={styles.badge}> {ratingText} </Text>}
      </View>
      <View style={isTile ? styles.infoTile : styles.inFoRow}>
        <Text style={styles.title} numberOfLines={isTile ? 1: undefined}> {movie.title} </Text>
        <Text> 
          {!isTile && <Text> {movie.genre} </Text>}
          {!isTile && <Text>{`Năm ${movie.year}`}</Text>}
          {!isTile && <Text>{ratingText}</Text>}
          <Text>{movie.isShowing ? '✅' : '❌'}</Text>
        </Text>
      </View>
    </TouchableOpacity>
  );
}

export default React.memo(MovieCard);

const styles = StyleSheet.create({
  card: {
    flexDirection: 'row',
    backgroundColor: '#fff',
    padding: 16,
    marginLeft: 8, 
    marginRight: 8,
    marginBottom: 8,
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 8,
  },
  cardTile:{
    flexDirection: 'column', 
    with: '48%'
  },
  imageRow: {
    width: 70,
    height: 100,
  },
  imageTile: {
    width: '100%',
    aspectRatio: 2/3
  },
  badge:{
    position: 'absolute',
    top: 6,
    right: 6, 
    backgroundColor: 'rgba(0,0,0,0.7)',
    color: '#fff', 
    paddingHorizontal: 6, 
    borderRadius: 6
  }, 
  infoTile:{
    marginTop: 6
  }, 
   inFoRow: { flex: 1, marginLeft: 8 },            
   title: { fontWeight: 'bold' }
});
