import {
  StyleSheet,
  Text,
  View,
  TextInput,
  FlatList,
  TouchableOpacity,
  Alert,
  ActivityIndicator,
  Switch,
  RefreshControl
} from 'react-native';
import react, { useState, useEffect, useMemo, useCallback } from 'react';
import { SafeAreaProvider, SafeAreaView } from 'react-native-safe-area-context';
import MovieCard, { Movie } from './components/MovieCard';
const API_URL = 'https://6ad62354f71f154ac486877a.mockapi.io/movies';

function HomeScreen() {
  const [movies, setMovies] = useState<Movie[]>([]);
  const [loading, setLoading] = useState(true);
  const [isTile, setTile] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const loadMovies = async () => {
    const res = await fetch(API_URL);
    const data = await res.json();
    setMovies(data);
    setLoading(false);
  };

  useEffect(() => {
    loadMovies();
  }, []);

  const handleSelect = useCallback((id: string) => {
    const movie = movies.filter((item) => item.id == id);
    if (movie) Alert.alert('Tên phim', movie.title);
  }, [movies]);

  const numColumns = isTile ? 2 : 1;
  const onRefresh = async ()=>{
    setRefreshing(true);
    loadMovies();
    setRefreshing(false);
  }
  return (
    <SafeAreaView>
      <View>
        <Text style={styles.title}>Title: Movie APP</Text>
      </View>
      <View style={styles.header}>
        <Text> Dang luoi </Text>
       <Switch  value={isTile} onValueChange={setTile}/>
      </View>
      <View>
        {loading ? (
          <ActivityIndicator size="large" />
        ) : (
          <>
            <FlatList
              key={String(numColumns)}
              data={movies}
              keyExtractor={(item) => item.id}
              numColumns={numColumns}
              columnWrapperStyle= {isTile ? styles.columnWapper : undefined }
              renderItem={({ item }) => (
                <MovieCard movie={item} layout={isTile?'title' : 'row'} onSelect={handleSelect}/>
              )}
              refreshControl={
                <RefreshControl refreshing={refreshing} onRefresh={onRefresh}/>
              }
            />
          </>
        )}
      </View>
    </SafeAreaView>
  );
}

export default function App() {
  return (
    <SafeAreaProvider>
      <HomeScreen />
    </SafeAreaProvider>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#ecf0f1',
    padding: 8,
  },
  paragraph: {
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  title: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  header:{
    flexDirection: 'row',
    alignItems:'center',
    marginTop: 8,
    marginBottom: 10
  },
  columnWapper:{
   justifyContent: 'space-between'
  }
});
