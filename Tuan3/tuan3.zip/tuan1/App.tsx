import React from 'react';
import {
  SafeAreaView,
  ScrollView,
  View,
  Text,
  Image,
  StyleSheet,
  StatusBar,
} from 'react-native';

// =============================================
// DATA DÙNG CHUNG
// =============================================
interface Book {
  id: string;
  title: string;
  author: string;
  price: number;
  cover: string;
  discount?: string;
  isNew?: boolean;
}

const books: Book[] = [
  {
    id: '1',
    title: 'Clean Code',
    author: 'Robert C. Martin',
    price: 250000,
    cover:
      'https://placehold.co/400x560/1e293b/ffffff.png?text=Clean+Code',
    discount: '-20%',
  },
  {
    id: '2',
    title: 'The Pragmatic Programmer',
    author: 'Andrew Hunt',
    price: 320000,
    cover:
      'https://placehold.co/400x560/164e63/ffffff.png?text=Pragmatic+Programmer',
    isNew: true,
  },
  {
    id: '3',
    title: 'Design Patterns',
    author: 'Erich Gamma',
    price: 350000,
    cover:
      'https://placehold.co/400x560/365314/ffffff.png?text=Design+Patterns',
    discount: '-15%',
  },
  {
    id: '4',
    title: 'You Don\'t Know JS',
    author: 'Kyle Simpson',
    price: 280000,
    cover:
      'https://placehold.co/400x560/7c2d12/ffffff.png?text=You+Dont+Know+JS',
  },
];

const categories = [
  'Văn học',
  'Kinh tế',
  'Thiếu nhi',
  'Kỹ năng sống',
  'Truyện tranh',
  'Công nghệ',
];

const formatPrice = (price: number): string =>
  `${price.toLocaleString('vi-VN')}đ`;

// =============================================
// BÀI 1: HEADER BOOKSTORE
// flexDirection: row
// justifyContent: space-between
// alignItems: center
// =============================================
function AppHeader() {
  return (
    <View style={styles.header}>
      <Text style={styles.logo}>BookStore</Text>

      <View style={styles.headerActions}>
        <Text style={styles.headerIcon}>⌕</Text>
        <Text style={styles.headerIcon}>🛒</Text>
      </View>
    </View>
  );
}

// =============================================
// BÀI 2: BOOK CARD ĐƠN
// Ảnh bên trái, thông tin bên phải.
// Cột thông tin dùng flex: 1 và space-between.
// =============================================
function BookListCard({ book }: { book: Book }) {
  return (
    <View style={styles.listCard}>
      <Image source={{ uri: book.cover }} style={styles.listCover} />

      <View style={styles.listInfo}>
        <View>
          <Text numberOfLines={2} style={styles.listTitle}>
            {book.title}
          </Text>
          <Text style={styles.author}>{book.author}</Text>
        </View>

        <Text style={styles.price}>{formatPrice(book.price)}</Text>
      </View>
    </View>
  );
}

// =============================================
// BÀI 3: CATEGORY CHIPS
// flexDirection: row + flexWrap: wrap + gap
// =============================================
function CategoryChips() {
  return (
    <View style={styles.section}>
      <Text style={styles.sectionTitle}>Danh mục sách</Text>

      <View style={styles.chipContainer}>
        {categories.map(category => (
          <View key={category} style={styles.chip}>
            <Text style={styles.chipText}>{category}</Text>
          </View>
        ))}
      </View>
    </View>
  );
}

// =============================================
// BÀI 4 + BÀI 5: BOOK GRID + BADGE OVERLAY
// Grid 2 cột: width 48%, flexWrap: wrap.
// Badge absolute nằm trên ảnh, không đẩy layout.
// =============================================
function BookGridItem({ book }: { book: Book }) {
  return (
    <View style={styles.gridCard}>
      {/* View này là containing block cho badge absolute */}
      <View style={styles.gridImageContainer}>
        <Image source={{ uri: book.cover }} style={styles.gridCover} />

        {book.discount ? (
          <View style={styles.discountBadge}>
            <Text style={styles.badgeText}>{book.discount}</Text>
          </View>
        ) : null}

        {book.isNew ? (
          <View style={styles.newBadge}>
            <Text style={styles.badgeText}>MỚI</Text>
          </View>
        ) : null}
      </View>

      <Text numberOfLines={2} style={styles.gridTitle}>
        {book.title}
      </Text>
      <Text style={styles.gridAuthor}>{book.author}</Text>
      <Text style={styles.price}>{formatPrice(book.price)}</Text>
    </View>
  );
}

function BookGrid() {
  return (
    <View style={styles.section}>
      <Text style={styles.sectionTitle}>Sách nổi bật</Text>

      <View style={styles.gridContainer}>
        {books.map(book => (
          <BookGridItem key={book.id} book={book} />
        ))}
      </View>
    </View>
  );
}

// =============================================
// APP
// Phần header nằm ngoài ScrollView nên không cuộn.
// Nội dung còn lại nằm trong ScrollView.
// =============================================
export default function App() {
  return (
    <SafeAreaView style={styles.safeArea}>
      <StatusBar barStyle="light-content" backgroundColor="#172554" />

      {/* Bài 1: Header cố định phía trên */}
      <AppHeader />

      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        <Text style={styles.pageTitle}>Thực hành Flexbox - Phần 1</Text>

        {/* Bài 2: Book Card đơn */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Bài 2 - Book Card</Text>
          <BookListCard book={books[0]} />
          <BookListCard book={books[1]} />
        </View>

        {/* Bài 3: Category Chips */}
        <CategoryChips />

        {/* Bài 4 + 5: Grid 2 cột và Badge overlay */}
        <BookGrid />
      </ScrollView>
    </SafeAreaView>
  );
}

// =============================================
// STYLESHEET
// =============================================
const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },

  // Bài 1 - Header
  header: {
    height: 56,
    paddingHorizontal: 16,
    backgroundColor: '#172554',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  logo: {
    color: '#ffffff',
    fontSize: 21,
    fontWeight: 'bold',
  },
  headerActions: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 18,
  },
  headerIcon: {
    color: '#ffffff',
    fontSize: 25,
  },

  // Vùng nội dung
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    padding: 16,
    paddingBottom: 32,
  },
  pageTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#0f172a',
    marginBottom: 16,
  },
  section: {
    marginBottom: 22,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#1e293b',
    marginBottom: 12,
  },

  // Bài 2 - Book Card đơn
  listCard: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    backgroundColor: '#ffffff',
    borderRadius: 12,
    padding: 10,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  listCover: {
    width: 80,
    height: 110,
    borderRadius: 6,
    backgroundColor: '#e2e8f0',
  },
  listInfo: {
    flex: 1,
    minHeight: 110,
    marginLeft: 12,
    flexDirection: 'column',
    justifyContent: 'space-between',
  },
  listTitle: {
    fontSize: 15,
    fontWeight: 'bold',
    color: '#0f172a',
  },
  author: {
    color: '#64748b',
    fontSize: 12,
    marginTop: 5,
  },

  // Bài 3 - Category Chips
  chipContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    alignContent: 'flex-start',
  },
  chip: {
    paddingHorizontal: 13,
    paddingVertical: 8,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: '#4f46e5',
    backgroundColor: '#eef2ff',
  },
  chipText: {
    color: '#3730a3',
    fontSize: 13,
  },

  // Bài 4 - Book Grid 2 cột
  gridContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  gridCard: {
    width: '48%',
    backgroundColor: '#ffffff',
    borderRadius: 12,
    padding: 9,
    marginBottom: 14,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  gridImageContainer: {
    width: '100%',
    aspectRatio: 3 / 4,
    position: 'relative',
    marginBottom: 9,
    borderRadius: 8,
    overflow: 'hidden',
    backgroundColor: '#e2e8f0',
  },
  gridCover: {
    width: '100%',
    height: '100%',
    resizeMode: 'cover',
  },
  gridTitle: {
    fontSize: 14,
    lineHeight: 19,
    fontWeight: 'bold',
    color: '#0f172a',
    minHeight: 38,
  },
  gridAuthor: {
    fontSize: 11,
    color: '#64748b',
    marginTop: 4,
    marginBottom: 7,
  },
  price: {
    color: '#b91c1c',
    fontSize: 14,
    fontWeight: 'bold',
  },

  // Bài 5 - Badge overlay
  discountBadge: {
    position: 'absolute',
    top: 6,
    left: 6,
    backgroundColor: '#dc2626',
    paddingHorizontal: 7,
    paddingVertical: 4,
    borderRadius: 5,
  },
  newBadge: {
    position: 'absolute',
    top: 6,
    left: 6,
    backgroundColor: '#ea580c',
    paddingHorizontal: 7,
    paddingVertical: 4,
    borderRadius: 5,
  },
  badgeText: {
    color: '#ffffff',
    fontSize: 10,
    fontWeight: 'bold',
  },
});
