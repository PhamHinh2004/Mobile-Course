import React, { useState } from 'react';
import {
  StyleSheet,
  Text,
  View,
  Image,
  TouchableOpacity,
  FlatList,
  SafeAreaView,
  ScrollView,
  StatusBar,
  Alert,
} from 'react-native';

// Định nghĩa kiểu dữ liệu cho xe đạp
interface Bike {
  id: string;
  name: string;
  price: number;
  originalPrice?: number;
  discount?: string;
  category: 'Roadbike' | 'Mountain';
  image: string;
  description: string;
  isFavorite?: boolean;
}

// Dữ liệu mẫu bám sát giao diện trong hình
const INITIAL_BIKES: Bike[] = [
  {
    id: '1',
    name: 'Pinarello',
    price: 1800,
    originalPrice: 2100,
    discount: '15% OFF',
    category: 'Mountain',
    image: 'https://pngimg.com/uploads/bicycle/bicycle_PNG5374.png',
    description:
      'It is a very important form of writing as we write almost everything in paragraphs, be it an answer, essay, story, emails, etc.',
    isFavorite: false,
  },
  {
    id: '2',
    name: 'Pina Mountain',
    price: 1700,
    originalPrice: 2000,
    discount: '15% OFF',
    category: 'Mountain',
    image: 'https://pngimg.com/uploads/bicycle/bicycle_PNG5365.png',
    description:
      'It is a very important form of writing as we write almost everything in paragraphs, be it an answer, essay, story, emails, etc.',
    isFavorite: false,
  },
  {
    id: '3',
    name: 'Pina Bike',
    price: 1500,
    originalPrice: 1800,
    discount: '15% OFF',
    category: 'Roadbike',
    image: 'https://pngimg.com/uploads/bicycle/bicycle_PNG5389.png',
    description:
      'It is a very important form of writing as we write almost everything in paragraphs, be it an answer, essay, story, emails, etc.',
    isFavorite: false,
  },
  {
    id: '4',
    name: 'Pinarello',
    price: 1900,
    originalPrice: 2250,
    discount: '15% OFF',
    category: 'Roadbike',
    image: 'https://pngimg.com/uploads/bicycle/bicycle_PNG5360.png',
    description:
      'It is a very important form of writing as we write almost everything in paragraphs, be it an answer, essay, story, emails, etc.',
    isFavorite: false,
  },
  {
    id: '5',
    name: 'Pinarello',
    price: 2700,
    originalPrice: 3100,
    discount: '15% OFF',
    category: 'Roadbike',
    image: 'https://pngimg.com/uploads/bicycle/bicycle_PNG5389.png',
    description:
      'It is a very important form of writing as we write almost everything in paragraphs, be it an answer, essay, story, emails, etc.',
    isFavorite: false,
  },
  {
    id: '6',
    name: 'Pinarello',
    price: 1350,
    originalPrice: 1600,
    discount: '15% OFF',
    category: 'Mountain',
    image: 'https://pngimg.com/uploads/bicycle/bicycle_PNG5365.png',
    description:
      'It is a very important form of writing as we write almost everything in paragraphs, be it an answer, essay, story, emails, etc.',
    isFavorite: false,
  },
];

export default function App() {
  // State quản lý màn hình hiện tại: 'Screen_01' | 'Screen_02' | 'Screen_03'
  const [currentScreen, setCurrentScreen] = useState<'Screen_01' | 'Screen_02' | 'Screen_03'>('Screen_01');
  const [bikes, setBikes] = useState<Bike[]>(INITIAL_BIKES);
  const [selectedCategory, setSelectedCategory] = useState<'All' | 'Roadbike' | 'Mountain'>('All');
  const [selectedBikeId, setSelectedBikeId] = useState<string>('2');

  // Lọc danh sách xe theo danh mục
  const filteredBikes =
    selectedCategory === 'All'
      ? bikes
      : bikes.filter((bike) => bike.category === selectedCategory);

  // Lấy thông tin xe đang được chọn ở Screen_03
  const selectedBike = bikes.find((b) => b.id === selectedBikeId) || bikes[0];

  // Hàm xử lý thả tim / bỏ tim
  const toggleFavorite = (id: string) => {
    setBikes((prevBikes) =>
      prevBikes.map((bike) =>
        bike.id === id ? { ...bike, isFavorite: !bike.isFavorite } : bike
      )
    );
  };

  // ==========================================
  // MÀN HÌNH 1: WELCOME SCREEN (Screen_01)
  // ==========================================
  if (currentScreen === 'Screen_01') {
    return (
      <SafeAreaView style={styles.container}>
        <StatusBar barStyle="dark-content" backgroundColor="#FFFFFF" />
        <View style={styles.screen1Container}>
          <Text style={styles.sloganText}>
            A premium online store for{'\n'}sporter and their stylish choice
          </Text>

          <View style={styles.heroImageBox}>
            <Image
              source={{ uri: 'https://pngimg.com/uploads/bicycle/bicycle_PNG5374.png' }}
              style={styles.heroImage}
              resizeMode="contain"
            />
          </View>

          <Text style={styles.shopTitle}>POWER BIKE{'\n'}SHOP</Text>

          <TouchableOpacity
            style={styles.primaryButton}
            activeOpacity={0.8}
            onPress={() => setCurrentScreen('Screen_02')}
          >
            <Text style={styles.primaryButtonText}>Get Started</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  // ==========================================
  // MÀN HÌNH 2: PRODUCT LIST (Screen_02)
  // ==========================================
  if (currentScreen === 'Screen_02') {
    return (
      <SafeAreaView style={styles.container}>
        <StatusBar barStyle="dark-content" backgroundColor="#FFFFFF" />
        <View style={styles.screen2Container}>
          {/* Header */}
          <View style={styles.headerRow}>
            <Text style={styles.headerTitle}>The world's Best Bike</Text>
            <TouchableOpacity onPress={() => setCurrentScreen('Screen_01')}>
              <Text style={styles.backHomeText}>Home</Text>
            </TouchableOpacity>
          </View>

          {/* Filter Tabs */}
          <View style={styles.filterRow}>
            {(['All', 'Roadbike', 'Mountain'] as const).map((category) => {
              const isActive = selectedCategory === category;
              return (
                <TouchableOpacity
                  key={category}
                  style={[styles.filterBtn, isActive && styles.filterBtnActive]}
                  onPress={() => setSelectedCategory(category)}
                >
                  <Text
                    style={[
                      styles.filterBtnText,
                      isActive && styles.filterBtnTextActive,
                    ]}
                  >
                    {category}
                  </Text>
                </TouchableOpacity>
              );
            })}
          </View>

          {/* Grid Danh Sách Xe */}
          <FlatList
            data={filteredBikes}
            keyExtractor={(item) => item.id}
            numColumns={2}
            showsVerticalScrollIndicator={false}
            columnWrapperStyle={styles.gridRow}
            contentContainerStyle={{ paddingBottom: 20 }}
            renderItem={({ item }) => (
              <TouchableOpacity
                style={styles.card}
                activeOpacity={0.85}
                onPress={() => {
                  setSelectedBikeId(item.id);
                  setCurrentScreen('Screen_03');
                }}
              >
                {/* Nút Tim góc trái trên */}
                <TouchableOpacity
                  style={styles.heartIconBtn}
                  onPress={() => toggleFavorite(item.id)}
                >
                  <Text style={styles.heartIconText}>
                    {item.isFavorite ? '❤️' : '🤍'}
                  </Text>
                </TouchableOpacity>

                <Image
                  source={{ uri: item.image }}
                  style={styles.cardImage}
                  resizeMode="contain"
                />
                <Text style={styles.cardTitle} numberOfLines={1}>
                  {item.name}
                </Text>
                <Text style={styles.cardPrice}>
                  <Text style={styles.currencySymbol}>$ </Text>
                  {item.price}
                </Text>
              </TouchableOpacity>
            )}
          />
        </View>
      </SafeAreaView>
    );
  }

  // ==========================================
  // MÀN HÌNH 3: PRODUCT DETAIL (Screen_03)
  // ==========================================
  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="dark-content" backgroundColor="#FFFFFF" />
      <ScrollView contentContainerStyle={styles.screen3Container}>
        {/* Nút quay lại */}
        <TouchableOpacity
          style={styles.backBtn}
          onPress={() => setCurrentScreen('Screen_02')}
        >
          <Text style={styles.backBtnText}>← Back to list</Text>
        </TouchableOpacity>

        {/* Khung ảnh sản phẩm lớn */}
        <View style={styles.detailImageBox}>
          <Image
            source={{ uri: selectedBike.image }}
            style={styles.detailImage}
            resizeMode="contain"
          />
        </View>

        {/* Tên & Giá khuyến mãi */}
        <Text style={styles.detailTitle}>{selectedBike.name}</Text>
        <View style={styles.priceRow}>
          <Text style={styles.discountText}>
            {selectedBike.discount || '15% OFF'} | {selectedBike.price}$
          </Text>
          <Text style={styles.originalPriceText}>
            {selectedBike.originalPrice || Math.round(selectedBike.price * 1.2)}$
          </Text>
        </View>

        {/* Mô tả */}
        <Text style={styles.sectionHeading}>Description</Text>
        <Text style={styles.descriptionText}>{selectedBike.description}</Text>

        {/* Thanh hành động dưới cùng */}
        <View style={styles.bottomActionRow}>
          <TouchableOpacity
            style={styles.detailHeartBtn}
            onPress={() => toggleFavorite(selectedBike.id)}
          >
            <Text style={{ fontSize: 24 }}>
              {selectedBike.isFavorite ? '❤️' : '🤍'}
            </Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.addToCartBtn}
            activeOpacity={0.8}
            onPress={() =>
              Alert.alert(
                'Thành công',
                `Đã thêm "${selectedBike.name}" vào giỏ hàng!`
              )
            }
          >
            <Text style={styles.addToCartText}>Add to card</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

// ==========================================
// STYLESHEET
// ==========================================
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },

  // --- Styles Screen 01 ---
  screen1Container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingVertical: 30,
  },
  sloganText: {
    fontSize: 18,
    fontWeight: '600',
    textAlign: 'center',
    color: '#111111',
    lineHeight: 26,
    marginTop: 10,
  },
  heroImageBox: {
    width: '100%',
    height: 330,
    backgroundColor: '#F8E6E5',
    borderRadius: 40,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  heroImage: {
    width: '100%',
    height: '100%',
  },
  shopTitle: {
    fontSize: 26,
    fontWeight: '800',
    textAlign: 'center',
    color: '#000000',
    letterSpacing: 1,
  },
  primaryButton: {
    width: '100%',
    backgroundColor: '#E94141',
    paddingVertical: 16,
    borderRadius: 30,
    alignItems: 'center',
  },
  primaryButtonText: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: '600',
  },

  // --- Styles Screen 02 ---
  screen2Container: {
    flex: 1,
    paddingHorizontal: 16,
    paddingTop: 16,
  },
  headerRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 18,
  },
  headerTitle: {
    fontSize: 22,
    fontWeight: '700',
    color: '#E94141',
  },
  backHomeText: {
    fontSize: 14,
    color: '#888888',
    textDecorationLine: 'underline',
  },
  filterRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 20,
    gap: 10,
  },
  filterBtn: {
    flex: 1,
    paddingVertical: 8,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#F3B4B4',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
  },
  filterBtnActive: {
    borderColor: '#E94141',
    backgroundColor: '#FFF5F5',
  },
  filterBtnText: {
    fontSize: 14,
    color: '#A0A0A0',
    fontWeight: '500',
  },
  filterBtnTextActive: {
    color: '#E94141',
    fontWeight: '700',
  },
  gridRow: {
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  card: {
    width: '48%',
    backgroundColor: '#FEF5ED',
    borderRadius: 16,
    padding: 12,
    alignItems: 'center',
    position: 'relative',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 4,
    elevation: 2,
  },
  heartIconBtn: {
    position: 'absolute',
    top: 10,
    left: 10,
    zIndex: 10,
  },
  heartIconText: {
    fontSize: 18,
  },
  cardImage: {
    width: 120,
    height: 110,
    marginTop: 14,
    marginBottom: 8,
  },
  cardTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#555555',
    marginBottom: 4,
  },
  cardPrice: {
    fontSize: 17,
    fontWeight: '700',
    color: '#111111',
  },
  currencySymbol: {
    color: '#F7941D',
    fontWeight: '700',
  },

  // --- Styles Screen 03 ---
  screen3Container: {
    flexGrow: 1,
    paddingHorizontal: 18,
    paddingTop: 12,
    paddingBottom: 24,
  },
  backBtn: {
    marginBottom: 10,
    alignSelf: 'flex-start',
  },
  backBtnText: {
    fontSize: 15,
    fontWeight: '600',
    color: '#555555',
  },
  detailImageBox: {
    width: '100%',
    height: 310,
    backgroundColor: '#FDECEC',
    borderRadius: 16,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
    marginBottom: 20,
  },
  detailImage: {
    width: '100%',
    height: '100%',
  },
  detailTitle: {
    fontSize: 28,
    fontWeight: '700',
    color: '#111111',
    marginBottom: 8,
  },
  priceRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
    gap: 24,
  },
  discountText: {
    fontSize: 18,
    color: '#777777',
    fontWeight: '500',
  },
  originalPriceText: {
    fontSize: 18,
    color: '#111111',
    fontWeight: '600',
    textDecorationLine: 'line-through',
  },
  sectionHeading: {
    fontSize: 18,
    fontWeight: '700',
    color: '#111111',
    marginBottom: 10,
  },
  descriptionText: {
    fontSize: 15,
    color: '#666666',
    lineHeight: 22,
    marginBottom: 30,
  },
  bottomActionRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginTop: 'auto',
    gap: 20,
  },
  detailHeartBtn: {
    padding: 10,
  },
  addToCartBtn: {
    flex: 1,
    backgroundColor: '#E94141',
    paddingVertical: 15,
    borderRadius: 30,
    alignItems: 'center',
  },
  addToCartText: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: '600',
  },
});