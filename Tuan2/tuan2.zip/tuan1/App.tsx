import React, {
  createContext,
  useContext,
  useEffect,
  useState,
} from 'react';
import type { ComponentType, ReactNode } from 'react';
import {
  ActivityIndicator,
  Alert,
  FlatList,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';

// ============================================================
// DATA + TYPES (data.ts được gộp vào cùng file để dễ thực hành)
// ============================================================

export interface Todo {
  id: string;
  title: string;
}

export interface Book {
  id: string;
  title: string;
  author: string;
  price: number;
  cover: string;
}

export interface Member {
  name: string;
  age: number;
  isAdmin: boolean;
}

export interface Order {
  id: string;
  date: string;
  total: number;
}

export const member: Member = {
  name: 'Nguyen Van A',
  age: 22,
  isAdmin: true,
};

export const initialTodos: Todo[] = [
  { id: '1', title: 'Learn TypeScript' },
  { id: '2', title: 'Learn React Native' },
];

export const books: Book[] = [
  {
    id: '1',
    title: 'Clean Code',
    author: 'Robert C. Martin',
    price: 250000,
    cover: '📘',
  },
  {
    id: '2',
    title: 'The Pragmatic Programmer',
    author: 'Andrew Hunt',
    price: 300000,
    cover: '📕',
  },
  {
    id: '3',
    title: 'Design Patterns',
    author: 'Erich Gamma',
    price: 350000,
    cover: '📗',
  },
];

export const orders: Order[] = [
  { id: 'ORD001', date: '10/11/2026', total: 250000 },
  { id: 'ORD002', date: '11/11/2026', total: 300000 },
];

// ============================================================
// BÀI 1 - UserCard: interface, primitive types, Props
// ============================================================

interface UserCardProps {
  name: string;
  age: number;
  isAdmin: boolean;
}

export function UserCard({ name, age, isAdmin }: UserCardProps) {
  return (
    <View style={styles.card}>
      <Text>Họ tên: {name}</Text>
      <Text>Tuổi: {age}</Text>
      <Text style={{ color: isAdmin ? 'green' : 'blue' }}>
        {isAdmin ? 'Quản trị viên' : 'Thành viên'}
      </Text>
    </View>
  );
}

// ============================================================
// BÀI 2 - Counter: useState, Type Inference
// ============================================================

export function Counter() {
  // TypeScript tự suy luận count có kiểu number.
  const [count, setCount] = useState(0);

  // Cách khai báo tường minh cũng hợp lệ:
  // const [count, setCount] = useState<number>(0);

  const increase = () => setCount(previous => previous + 1);
  const decrease = () => setCount(previous => Math.max(0, previous - 1));

  return (
    <View style={styles.card}>
      <Text style={styles.counterText}>Count: {count}</Text>
      <View style={styles.row}>
        <Pressable style={styles.smallButton} onPress={increase}>
          <Text>+</Text>
        </Pressable>
        <Pressable style={styles.smallButton} onPress={decrease}>
          <Text>-</Text>
        </Pressable>
      </View>
    </View>
  );
}

// ============================================================
// BÀI 3 - TodoList: Todo[], object type, map, filter
// ============================================================

export function TodoList() {
  const [todos, setTodos] = useState<Todo[]>(initialTodos);

  const addTodo = () => {
    const newTodo: Todo = {
      id: Date.now().toString(),
      title: `Task ${todos.length + 1}`,
    };
    setTodos(previous => [...previous, newTodo]);
  };

  const deleteTodo = (id: string) => {
    setTodos(previous => previous.filter(item => item.id !== id));
  };

  return (
    <View style={styles.card}>
      <Text style={styles.heading}>Todo List</Text>
      {todos.map(item => (
        <View key={item.id} style={styles.row}>
          <Text>{item.title}</Text>
          <Pressable onPress={() => deleteTodo(item.id)}>
            <Text style={styles.deleteText}>Delete</Text>
          </Pressable>
        </View>
      ))}
      <Pressable style={styles.smallButton} onPress={addTodo}>
        <Text>Add Todo</Text>
      </Pressable>
    </View>
  );
}

// ============================================================
// BÀI 4 - MyButton: optional property, callback function
// ============================================================

interface MyButtonProps {
  label: string;
  onPress: () => void;
  color?: string;
}

export function MyButton({
  label,
  onPress,
  color = 'blue',
}: MyButtonProps) {
  return (
    <Pressable
      onPress={onPress}
      style={[styles.myButton, { backgroundColor: color }]}
    >
      <Text style={styles.whiteText}>{label}</Text>
    </Pressable>
  );
}

// ============================================================
// BÀI 5 - LiveInput: TextInput onChangeText nhận string
// ============================================================

export function LiveInput() {
  const [value, setValue] = useState<string>('');

  const handleChange = (text: string) => {
    setValue(text);
  };

  return (
    <View style={styles.card}>
      <Text>Nhập nội dung:</Text>
      <TextInput
        style={styles.input}
        value={value}
        onChangeText={handleChange}
        placeholder="Nhập text..."
      />
      <Text>Số ký tự: {value.length}</Text>
    </View>
  );
}

// ============================================================
// BÀI 6 - LoadingContainer: ReactNode, children
// ============================================================

interface LoadingContainerProps {
  isLoading: boolean;
  children: ReactNode;
}

export function LoadingContainer({
  isLoading,
  children,
}: LoadingContainerProps) {
  if (isLoading) {
    return (
      <View style={styles.loadingBox}>
        <ActivityIndicator size="large" color="blue" />
      </View>
    );
  }

  return <View>{children}</View>;
}

// ============================================================
// BÀI 7 - GenderSelector: Union Types
// ============================================================

type Gender = 'male' | 'female' | 'other';

export function GenderSelector() {
  const [gender, setGender] = useState<Gender>('male');

  const options: Gender[] = ['male', 'female', 'other'];

  return (
    <View style={styles.card}>
      <Text style={styles.heading}>Gender: {gender}</Text>
      <View style={styles.row}>
        {options.map(option => (
          <Pressable
            key={option}
            onPress={() => setGender(option)}
            style={[
              styles.genderButton,
              gender === option && styles.genderButtonSelected,
            ]}
          >
            <Text>{option}</Text>
          </Pressable>
        ))}
      </View>
    </View>
  );
}

// ============================================================
// BÀI 8 - AppButton: Variant Props + Record
// ============================================================

type ButtonVariant = 'primary' | 'secondary' | 'outline' | 'danger';
type ButtonSize = 'small' | 'medium' | 'large';

interface AppButtonProps {
  title: string;
  variant?: ButtonVariant;
  size?: ButtonSize;
  onPress: () => void;
  disabled?: boolean;
  loading?: boolean;
  icon?: ReactNode;
}

const variantStyles: Record<
  ButtonVariant,
  { backgroundColor: string; borderColor: string; textColor: string }
> = {
  primary: {
    backgroundColor: '#2563eb',
    borderColor: '#2563eb',
    textColor: '#ffffff',
  },
  secondary: {
    backgroundColor: '#64748b',
    borderColor: '#64748b',
    textColor: '#ffffff',
  },
  outline: {
    backgroundColor: 'transparent',
    borderColor: '#2563eb',
    textColor: '#2563eb',
  },
  danger: {
    backgroundColor: '#dc2626',
    borderColor: '#dc2626',
    textColor: '#ffffff',
  },
};

const sizeStyles: Record<
  ButtonSize,
  { paddingVertical: number; paddingHorizontal: number; fontSize: number }
> = {
  small: { paddingVertical: 6, paddingHorizontal: 10, fontSize: 12 },
  medium: { paddingVertical: 10, paddingHorizontal: 16, fontSize: 14 },
  large: { paddingVertical: 14, paddingHorizontal: 20, fontSize: 16 },
};

export function AppButton({
  title,
  variant = 'primary',
  size = 'medium',
  onPress,
  disabled = false,
  loading = false,
  icon,
}: AppButtonProps) {
  const currentVariant = variantStyles[variant];
  const currentSize = sizeStyles[size];
  const isDisabled = disabled || loading;

  return (
    <Pressable
      onPress={onPress}
      disabled={isDisabled}
      style={[
        styles.appButton,
        {
          backgroundColor: currentVariant.backgroundColor,
          borderColor: currentVariant.borderColor,
          paddingVertical: currentSize.paddingVertical,
          paddingHorizontal: currentSize.paddingHorizontal,
        },
        isDisabled && styles.disabled,
      ]}
    >
      <View style={styles.buttonContent}>
        {loading ? (
          <ActivityIndicator color={currentVariant.textColor} />
        ) : (
          <>
            {icon ? <View style={styles.iconWrapper}>{icon}</View> : null}
            <Text
              style={{
                color: currentVariant.textColor,
                fontSize: currentSize.fontSize,
              }}
            >
              {title}
            </Text>
          </>
        )}
      </View>
    </Pressable>
  );
}

// ============================================================
// BÀI 9 - HOC: Generic + ComponentType + Intersection Type
// ============================================================

interface ErrorViewProps {
  message?: string;
  onRetry: () => void;
}

function ErrorView({ message, onRetry }: ErrorViewProps) {
  return (
    <View style={styles.errorBox}>
      <Text>{message ?? 'Có lỗi xảy ra!'}</Text>
      <Pressable onPress={onRetry} style={styles.smallButton}>
        <Text style={styles.retryText}>Thử lại</Text>
      </Pressable>
    </View>
  );
}

interface WithLoadingProps {
  isLoading: boolean;
  isError: boolean;
  errorMessage?: string;
  onRetry: () => void;
}

export function withLoadingState<P extends object>(
  WrappedComponent: ComponentType<P>,
) {
  type Props = P & WithLoadingProps;

  function WithLoadingState(props: Props) {
    const {
      isLoading,
      isError,
      errorMessage,
      onRetry,
      ...restProps
    } = props;

    if (isLoading) {
      return (
        <View style={styles.fullScreenLoading}>
          <ActivityIndicator size="large" color="blue" />
        </View>
      );
    }

    if (isError) {
      return <ErrorView message={errorMessage} onRetry={onRetry} />;
    }

    return <WrappedComponent {...(restProps as P)} />;
  }

  return WithLoadingState;
}

interface BookListScreenProps {
  books: Book[];
}

function BookListScreen({ books: bookItems }: BookListScreenProps) {
  return (
    <View style={styles.card}>
      <Text style={styles.heading}>Danh sách sách</Text>
      {bookItems.map(book => (
        <Text key={book.id} style={styles.listItem}>
          {book.title} - {book.price.toLocaleString('vi-VN')}đ
        </Text>
      ))}
    </View>
  );
}

interface OrderHistoryScreenProps {
  orders: Order[];
}

function OrderHistoryScreen({ orders: orderItems }: OrderHistoryScreenProps) {
  return (
    <View style={styles.card}>
      <Text style={styles.heading}>Lịch sử đơn hàng</Text>
      {orderItems.map(order => (
        <Text key={order.id} style={styles.listItem}>
          {order.id} - {order.total.toLocaleString('vi-VN')}đ
        </Text>
      ))}
    </View>
  );
}

export const BookListWithLoading = withLoadingState(BookListScreen);
export const OrderHistoryWithLoading = withLoadingState(OrderHistoryScreen);

// ============================================================
// BÀI 10 - Compound Component: Context + useContext
// ============================================================

interface BookCardContextValue {
  book: Book;
  isFavorite: boolean;
  toggleFavorite: () => void;
}

const BookCardContext = createContext<BookCardContextValue | null>(null);

function useBookCard() {
  const context = useContext(BookCardContext);

  if (context === null) {
    throw new Error('BookCard components phải nằm bên trong BookCard.');
  }

  return context;
}

interface BookCardProps {
  book: Book;
  children: ReactNode;
}

function BookCardRoot({ book, children }: BookCardProps) {
  const [isFavorite, setIsFavorite] = useState(false);

  const toggleFavorite = () => {
    setIsFavorite(previous => !previous);
  };

  const contextValue: BookCardContextValue = {
    book,
    isFavorite,
    toggleFavorite,
  };

  return (
    <BookCardContext.Provider value={contextValue}>
      <View style={styles.bookCard}>{children}</View>
    </BookCardContext.Provider>
  );
}

function BookCover() {
  const { book } = useBookCard();

  return (
    <View style={styles.bookCover}>
      <Text style={styles.bookCoverText}>{book.cover}</Text>
    </View>
  );
}

function BookTitle() {
  const { book } = useBookCard();
  return <Text style={styles.bookTitle}>{book.title}</Text>;
}

function BookPrice() {
  const { book } = useBookCard();
  return <Text>Giá: {book.price.toLocaleString('vi-VN')}đ</Text>;
}

function FavoriteButton() {
  const { isFavorite, toggleFavorite } = useBookCard();

  return (
    <Pressable onPress={toggleFavorite} style={styles.smallButton}>
      <Text>{isFavorite ? '❤️ Đã yêu thích' : '♡ Yêu thích'}</Text>
    </Pressable>
  );
}

export const BookCard = Object.assign(BookCardRoot, {
  Cover: BookCover,
  Title: BookTitle,
  Price: BookPrice,
  FavoriteButton,
});

// ============================================================
// PHẦN 2 - API & ASYNC: TYPES + API ENDPOINTS
// ============================================================

// Bài 9: JSONPlaceholder /todos thực tế trả về userId, id, title, completed.
// Vì vậy dữ liệu này là Todo, không phải Post/News.
export interface JsonPlaceholderTodo {
  userId: number;
  id: number;
  title: string;
  completed: boolean;
}

export interface JsonPlaceholderUser {
  id: number;
  name: string;
  username: string;
  email: string;
  phone: string;
  website: string;
}

// Các trường được dùng trong bài thực hành với DummyJSON.
export interface DummyProduct {
  id: number;
  title: string;
  description: string;
  price: number;
  category: string;
  thumbnail: string;
  rating?: number;
  brand?: string;
}

interface DummyProductListResponse {
  products: DummyProduct[];
  total: number;
  skip: number;
  limit: number;
}

// Generic Interface cho dữ liệu phân trang của ứng dụng.
export interface ApiResponse<T> {
  data: T[];
  total: number;
  page: number;
}

export const API_URLS = {
  todos: 'https://jsonplaceholder.typicode.com/todos',
  user: 'https://jsonplaceholder.typicode.com/users/1',
  products: 'https://dummyjson.com/products',
  productSearch: 'https://dummyjson.com/products/search',
};

// CustomError dùng chung cho lỗi API.
export interface CustomError {
  message: string;
  status?: number;
}

class ApiRequestError extends Error implements CustomError {
  status?: number;

  constructor(message: string, status?: number) {
    super(message);
    this.name = 'ApiRequestError';
    this.status = status;
  }
}

// Type guard: kiểm tra một giá trị unknown có dạng CustomError hay không.
function isCustomError(error: unknown): error is CustomError {
  if (typeof error !== 'object' || error === null || !('message' in error)) {
    return false;
  }

  return typeof error.message === 'string';
}

// Generic function: dùng được cho nhiều kiểu response khác nhau.
export async function fetchJson<T>(url: string): Promise<T> {
  const response = await fetch(url);

  // fetch không tự throw khi server trả HTTP 404/500, cần kiểm tra response.ok.
  if (!response.ok) {
    throw new ApiRequestError(
      `Request thất bại: ${response.status} ${response.statusText}`,
      response.status,
    );
  }

  // Đây là type assertion. Nó không tự kiểm tra JSON ở runtime.
  return (await response.json()) as T;
}

// ============================================================
// BÀI 9 - NEWS FEED: fetch + async/await + FlatList
// Endpoint là /todos nên hiển thị tiêu đề Todo từ JSONPlaceholder.
// ============================================================

export function NewsFeed() {
  const [todos, setTodos] = useState<JsonPlaceholderTodo[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  const loadTodos = async (): Promise<void> => {
    setLoading(true);
    setError(null);

    try {
      const data = await fetchJson<JsonPlaceholderTodo[]>(API_URLS.todos);
      setTodos(data);
    } catch (error: unknown) {
      setError(
        isCustomError(error)
          ? error.message
          : error instanceof Error
            ? error.message
            : 'Đã xảy ra lỗi không xác định.',
      );
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void loadTodos();
  }, []);

  if (loading) {
    return (
      <View style={styles.apiCentered}>
        <ActivityIndicator size="large" color="#2563eb" />
        <Text style={styles.mutedText}>Đang tải danh sách...</Text>
      </View>
    );
  }

  if (error) {
    return (
      <View style={styles.apiPanel}>
        <Text style={styles.errorText}>{error}</Text>
        <AppButton title="Thử lại" onPress={() => void loadTodos()} />
      </View>
    );
  }

  return (
    <View style={styles.apiPanel}>
      <Text style={styles.heading}>JSONPlaceholder Todos</Text>
      <Text style={styles.mutedText}>Tổng số: {todos.length}</Text>

      <FlatList
        data={todos}
        keyExtractor={item => item.id.toString()}
        contentContainerStyle={styles.apiListContent}
        ItemSeparatorComponent={() => <View style={styles.separator} />}
        renderItem={({ item }) => (
          <View style={styles.apiListRow}>
            <Text style={styles.apiItemTitle}>{item.title}</Text>
            <Text style={item.completed ? styles.successText : styles.mutedText}>
              {item.completed ? 'Đã hoàn thành' : 'Chưa hoàn thành'}
            </Text>
          </View>
        )}
      />
    </View>
  );
}

// ============================================================
// BÀI 10 - USER PROFILE: User | null + Optional Chaining
// ============================================================

export function UserProfileDetail() {
  const [user, setUser] = useState<JsonPlaceholderUser | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const loadUser = async (): Promise<void> => {
      try {
        const data = await fetchJson<JsonPlaceholderUser>(API_URLS.user);
        setUser(data);
      } catch (error: unknown) {
        setError(
          error instanceof Error ? error.message : 'Không thể tải thông tin user.',
        );
      }
    };

    void loadUser();
  }, []);

  // Khi user === null và chưa có lỗi, màn hình để trống theo yêu cầu bài tập.
  if (user === null) {
    return (
      <View style={styles.apiPanel}>
        {error ? <Text style={styles.errorText}>{error}</Text> : null}
      </View>
    );
  }

  return (
    <View style={styles.apiPanel}>
      <Text style={styles.heading}>User Profile</Text>
      {/* Optional chaining: user?.name */}
      <Text>Họ tên: {user?.name}</Text>
      <Text>Username: {user?.username}</Text>
      <Text>Email: {user?.email}</Text>
      <Text>Phone: {user?.phone}</Text>
      <Text>Website: {user?.website}</Text>
    </View>
  );
}

// ============================================================
// BÀI 11 - PRODUCT SEARCH: typed async function + DummyJSON
// ============================================================

export async function fetchProducts(
  keyword: string,
  limit: number,
): Promise<DummyProduct[]> {
  const query = encodeURIComponent(keyword.trim());
  const url = `${API_URLS.productSearch}?q=${query}&limit=${limit}`;
  const response = await fetchJson<DummyProductListResponse>(url);
  return response.products;
}

export function ProductSearchApi() {
  const [keyword, setKeyword] = useState<string>('phone');
  const [products, setProducts] = useState<DummyProduct[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [hasSearched, setHasSearched] = useState<boolean>(false);

  const handleSearch = async (): Promise<void> => {
    if (!keyword.trim()) {
      setProducts([]);
      setError('Vui lòng nhập từ khóa tìm kiếm.');
      setHasSearched(false);
      return;
    }

    setLoading(true);
    setError(null);
    setHasSearched(true);

    try {
      const result = await fetchProducts(keyword, 10);
      setProducts(result);
    } catch (error: unknown) {
      setError(
        error instanceof Error ? error.message : 'Không thể tìm kiếm sản phẩm.',
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={styles.apiPanel}>
      <Text style={styles.heading}>Tìm kiếm sản phẩm</Text>
      <TextInput
        value={keyword}
        onChangeText={setKeyword}
        placeholder="Nhập tên sản phẩm, ví dụ: phone"
        style={styles.input}
        returnKeyType="search"
        onSubmitEditing={() => void handleSearch()}
      />
      <AppButton
        title="Tìm kiếm"
        onPress={() => void handleSearch()}
        loading={loading}
      />

      {loading ? <ActivityIndicator style={styles.inlineLoader} /> : null}
      {error ? <Text style={styles.errorText}>{error}</Text> : null}

      {!loading && hasSearched && !error ? (
        <Text style={styles.mutedText}>Tìm thấy {products.length} sản phẩm</Text>
      ) : null}

      <FlatList
        data={products}
        keyExtractor={item => item.id.toString()}
        contentContainerStyle={styles.apiListContent}
        ItemSeparatorComponent={() => <View style={styles.separator} />}
        ListEmptyComponent={
          hasSearched && !loading && !error ? (
            <Text>Không tìm thấy sản phẩm.</Text>
          ) : null
        }
        renderItem={({ item }) => (
          <View style={styles.apiListRow}>
            <Text style={styles.apiItemTitle}>{item.title}</Text>
            <Text>{item.price.toLocaleString('en-US')} USD</Text>
            <Text style={styles.mutedText}>{item.category}</Text>
          </View>
        )}
      />
    </View>
  );
}

// ============================================================
// BÀI 12 - API ERROR HANDLING: catch unknown + type guard
// ============================================================

export function ApiErrorDemo() {
  const [message, setMessage] = useState<string>('Chưa thực hiện request lỗi.');

  const requestWrongUrl = async (): Promise<void> => {
    try {
      // Cố tình gọi sai endpoint để nhận HTTP 404.
      await fetchJson<unknown>('https://dummyjson.com/this-endpoint-does-not-exist');
      setMessage('Request thành công (không phải kết quả mong đợi của bài này).');
    } catch (error: unknown) {
      // Không nên mặc định error luôn là AxiosError hoặc Error.
      const customError: CustomError = isCustomError(error)
        ? error
        : {
            message:
              error instanceof Error ? error.message : 'Đã xảy ra lỗi không xác định.',
          };

      const fullMessage = customError.status
        ? `${customError.message} (HTTP ${customError.status})`
        : customError.message;

      setMessage(fullMessage);
      Alert.alert('API Error', fullMessage);
    }
  };

  return (
    <View style={styles.apiPanel}>
      <Text style={styles.heading}>Thử gọi API sai URL</Text>
      <Text style={styles.mutedText}>{message}</Text>
      <AppButton title="Gọi endpoint sai" variant="danger" onPress={() => void requestWrongUrl()} />
    </View>
  );
}

// ============================================================
// BÀI 13 - FILTER GENERIC: hàm lọc dùng lại cho nhiều object
// ============================================================

// T yêu cầu phải có thuộc tính name kiểu string.
export function filterByName<T extends { name: string }>(
  items: T[],
  keyword: string,
): T[] {
  const normalizedKeyword = keyword.trim().toLowerCase();

  if (!normalizedKeyword) {
    return items;
  }

  return items.filter(item =>
    item.name.toLowerCase().includes(normalizedKeyword),
  );
}

interface Publisher {
  id: number;
  name: string;
  country: string;
}

interface StoreMember {
  id: number;
  name: string;
  membership: 'silver' | 'gold';
}

const publishers: Publisher[] = [
  { id: 1, name: 'Penguin Random House', country: 'USA' },
  { id: 2, name: 'HarperCollins', country: 'USA' },
  { id: 3, name: 'Oxford University Press', country: 'UK' },
];

const storeMembers: StoreMember[] = [
  { id: 1, name: 'Nguyen Van An', membership: 'gold' },
  { id: 2, name: 'Tran Thi Binh', membership: 'silver' },
  { id: 3, name: 'Le Minh Chau', membership: 'gold' },
];

export function FilteredListGenericDemo() {
  const [keyword, setKeyword] = useState<string>('');

  // Cùng một hàm generic được dùng cho hai loại object khác nhau.
  const filteredPublishers = filterByName(publishers, keyword);
  const filteredMembers = filterByName(storeMembers, keyword);

  return (
    <View style={styles.apiPanel}>
      <Text style={styles.heading}>Lọc nhà xuất bản và thành viên</Text>
      <TextInput
        value={keyword}
        onChangeText={setKeyword}
        placeholder="Nhập tên cần tìm..."
        style={styles.input}
      />

      <Text style={styles.subHeading}>Nhà xuất bản</Text>
      {filteredPublishers.map(item => (
        <Text key={item.id} style={styles.listLine}>
          {item.name} ({item.country})
        </Text>
      ))}

      <Text style={styles.subHeading}>Thành viên</Text>
      {filteredMembers.map(item => (
        <Text key={item.id} style={styles.listLine}>
          {item.name} ({item.membership})
        </Text>
      ))}
    </View>
  );
}

// ============================================================
// BÀI 14 - PAGINATION: Generic Interface ApiResponse<T>
// DummyJSON trả products, total, skip, limit.
// Ta chuyển đổi response đó thành { data, total, page } của ứng dụng.
// ============================================================

export async function fetchProductsPage(
  page: number,
  limit: number,
): Promise<ApiResponse<DummyProduct>> {
  const skip = (page - 1) * limit;
  const url = `${API_URLS.products}?limit=${limit}&skip=${skip}`;
  const response = await fetchJson<DummyProductListResponse>(url);

  return {
    data: response.products,
    total: response.total,
    page,
  };
}

export function PaginationDemo() {
  const PAGE_SIZE = 5;
  const [result, setResult] = useState<ApiResponse<DummyProduct> | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  const loadPage = async (page: number): Promise<void> => {
    setLoading(true);
    setError(null);

    try {
      const response = await fetchProductsPage(page, PAGE_SIZE);
      setResult(response);
    } catch (error: unknown) {
      setError(error instanceof Error ? error.message : 'Không thể tải trang.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void loadPage(1);
  }, []);

  const currentPage = result?.page ?? 1;
  const totalPages = result ? Math.ceil(result.total / PAGE_SIZE) : 0;

  return (
    <View style={styles.apiPanel}>
      <Text style={styles.heading}>Phân trang sản phẩm</Text>
      <View style={styles.row}>
        <Pressable
          disabled={loading || currentPage <= 1}
          onPress={() => void loadPage(currentPage - 1)}
          style={[styles.smallButton, (loading || currentPage <= 1) && styles.disabled]}
        >
          <Text>Trang trước</Text>
        </Pressable>
        <Text>Trang {currentPage} / {totalPages || '...'}</Text>
        <Pressable
          disabled={loading || currentPage >= totalPages}
          onPress={() => void loadPage(currentPage + 1)}
          style={[styles.smallButton, (loading || currentPage >= totalPages) && styles.disabled]}
        >
          <Text>Trang sau</Text>
        </Pressable>
      </View>

      {loading ? <ActivityIndicator style={styles.inlineLoader} /> : null}
      {error ? <Text style={styles.errorText}>{error}</Text> : null}
      <Text style={styles.mutedText}>Tổng số sản phẩm: {result?.total ?? 0}</Text>

      <FlatList
        data={result?.data ?? []}
        keyExtractor={item => item.id.toString()}
        contentContainerStyle={styles.apiListContent}
        ItemSeparatorComponent={() => <View style={styles.separator} />}
        renderItem={({ item }) => (
          <View style={styles.apiListRow}>
            <Text style={styles.apiItemTitle}>{item.title}</Text>
            <Text>{item.price.toLocaleString('en-US')} USD</Text>
          </View>
        )}
      />
    </View>
  );
}

// ============================================================
// BÀI 15 - PULL TO REFRESH: loading và refreshing độc lập
// ============================================================

export function PullToRefreshDemo() {
  const [products, setProducts] = useState<DummyProduct[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [refreshing, setRefreshing] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const loadInitialProducts = async (): Promise<void> => {
    setLoading(true);
    setError(null);

    try {
      const response = await fetchProductsPage(1, 10);
      setProducts(response.data);
    } catch (error: unknown) {
      setError(error instanceof Error ? error.message : 'Không thể tải sản phẩm.');
    } finally {
      setLoading(false);
    }
  };

  const refreshProducts = async (): Promise<void> => {
    setRefreshing(true);
    setError(null);

    try {
      const response = await fetchProductsPage(1, 10);
      setProducts(response.data);
    } catch (error: unknown) {
      setError(error instanceof Error ? error.message : 'Không thể làm mới dữ liệu.');
    } finally {
      // Luôn tắt refreshing dù request thành công hay thất bại.
      setRefreshing(false);
    }
  };

  useEffect(() => {
    void loadInitialProducts();
  }, []);

  if (loading && products.length === 0) {
    return (
      <View style={styles.apiCentered}>
        <ActivityIndicator size="large" color="#2563eb" />
        <Text style={styles.mutedText}>Đang tải sản phẩm lần đầu...</Text>
      </View>
    );
  }

  return (
    <View style={styles.apiPanel}>
      <Text style={styles.heading}>Kéo xuống để làm mới</Text>
      {error ? <Text style={styles.errorText}>{error}</Text> : null}
      <FlatList
        data={products}
        keyExtractor={item => item.id.toString()}
        refreshing={refreshing}
        onRefresh={() => void refreshProducts()}
        contentContainerStyle={styles.apiListContent}
        ItemSeparatorComponent={() => <View style={styles.separator} />}
        renderItem={({ item }) => (
          <View style={styles.apiListRow}>
            <Text style={styles.apiItemTitle}>{item.title}</Text>
            <Text>{item.price.toLocaleString('en-US')} USD</Text>
          </View>
        )}
        ListEmptyComponent={<Text>Không có sản phẩm.</Text>}
      />
    </View>
  );
}

// Các tab để mở từng bài API. Mỗi FlatList được hiển thị riêng,
// tránh lồng nhiều FlatList dọc bên trong một ScrollView dọc.
type ApiDemoKey = 'news' | 'user' | 'search' | 'error' | 'filter' | 'pagination' | 'refresh';

const apiDemoOptions: { key: ApiDemoKey; title: string }[] = [
  { key: 'news', title: 'Bài 9: Todos' },
  { key: 'user', title: 'Bài 10: User' },
  { key: 'search', title: 'Bài 11: Search' },
  { key: 'error', title: 'Bài 12: Error' },
  { key: 'filter', title: 'Bài 13: Generic' },
  { key: 'pagination', title: 'Bài 14: Pagination' },
  { key: 'refresh', title: 'Bài 15: Refresh' },
];


// ============================================================
// APP - Chuyển đổi giữa phần Props & State và phần API & Async
// ============================================================

export default function App() {
  const [module, setModule] = useState<'props' | 'api'>('props');
  const [activeApiDemo, setActiveApiDemo] = useState<ApiDemoKey>('news');

  const renderApiDemo = () => {
    switch (activeApiDemo) {
      case 'news':
        return <NewsFeed />;
      case 'user':
        return <UserProfileDetail />;
      case 'search':
        return <ProductSearchApi />;
      case 'error':
        return <ApiErrorDemo />;
      case 'filter':
        return <FilteredListGenericDemo />;
      case 'pagination':
        return <PaginationDemo />;
      case 'refresh':
        return <PullToRefreshDemo />;
      default:
        return null;
    }
  };

  return (
    <View style={styles.appRoot}>
      <View style={styles.moduleTabs}>
        <Pressable
          onPress={() => setModule('props')}
          style={[styles.moduleTab, module === 'props' && styles.moduleTabActive]}
        >
          <Text style={[styles.moduleTabText, module === 'props' && styles.moduleTabTextActive]}>
            Props & State
          </Text>
        </Pressable>
        <Pressable
          onPress={() => setModule('api')}
          style={[styles.moduleTab, module === 'api' && styles.moduleTabActive]}
        >
          <Text style={[styles.moduleTabText, module === 'api' && styles.moduleTabTextActive]}>
            API & Async
          </Text>
        </Pressable>
      </View>

      {module === 'props' ? (
        <ScrollView contentContainerStyle={styles.screen}>
          <Text style={styles.appTitle}>BookStore - TypeScript Practice</Text>

          <Text style={styles.sectionTitle}>Bài 1: UserCard</Text>
          <UserCard {...member} />

          <Text style={styles.sectionTitle}>Bài 2: Counter</Text>
          <Counter />

          <Text style={styles.sectionTitle}>Bài 3: TodoList</Text>
          <TodoList />

          <Text style={styles.sectionTitle}>Bài 4: MyButton</Text>
          <MyButton
            label="Thêm vào giỏ hàng"
            color="green"
            onPress={() => console.log('Added to cart')}
          />

          <Text style={styles.sectionTitle}>Bài 5: LiveInput</Text>
          <LiveInput />

          <Text style={styles.sectionTitle}>Bài 6: LoadingContainer</Text>
          <LoadingContainer isLoading={false}>
            <Text>Danh sách sách BookStore</Text>
            <Text>Clean Code</Text>
            <Text>Design Patterns</Text>
          </LoadingContainer>

          <Text style={styles.sectionTitle}>Bài 7: GenderSelector</Text>
          <GenderSelector />

          <Text style={styles.sectionTitle}>Bài 8: AppButton</Text>
          <AppButton
            title="Thêm vào giỏ hàng"
            variant="primary"
            onPress={() => console.log('Add cart')}
            icon={<Text>🛒</Text>}
          />
          <AppButton
            title="Xem chi tiết"
            variant="outline"
            onPress={() => console.log('View detail')}
          />
          <AppButton
            title="Xóa sách"
            variant="danger"
            onPress={() => console.log('Delete book')}
          />

          <Text style={styles.sectionTitle}>Bài 9: HOC - Book List</Text>
          <BookListWithLoading
            books={books}
            isLoading={false}
            isError={false}
            onRetry={() => console.log('Retry books')}
          />

          <Text style={styles.sectionTitle}>Bài 9: HOC - Order History</Text>
          <OrderHistoryWithLoading
            orders={orders}
            isLoading={false}
            isError={false}
            onRetry={() => console.log('Retry orders')}
          />

          <Text style={styles.sectionTitle}>Bài 10: Compound Component</Text>
          {books.map(book => (
            <BookCard key={book.id} book={book}>
              <BookCard.Cover />
              <BookCard.Title />
              <BookCard.Price />
              <BookCard.FavoriteButton />
            </BookCard>
          ))}
        </ScrollView>
      ) : (
        <View style={styles.apiRoot}>
          <View style={styles.apiMenu}>
            <ScrollView horizontal showsHorizontalScrollIndicator={false}>
              {apiDemoOptions.map(option => (
                <Pressable
                  key={option.key}
                  onPress={() => setActiveApiDemo(option.key)}
                  style={[
                    styles.apiMenuButton,
                    activeApiDemo === option.key && styles.apiMenuButtonActive,
                  ]}
                >
                  <Text
                    style={[
                      styles.apiMenuText,
                      activeApiDemo === option.key && styles.apiMenuTextActive,
                    ]}
                  >
                    {option.title}
                  </Text>
                </Pressable>
              ))}
            </ScrollView>
          </View>
          <View style={styles.apiDemoContainer}>{renderApiDemo()}</View>
        </View>
      )}
    </View>
  );
}

// ============================================================
// STYLES
// ============================================================

const styles = StyleSheet.create({
  appRoot: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  moduleTabs: {
    flexDirection: 'row',
    paddingTop: 48,
    paddingHorizontal: 16,
    paddingBottom: 10,
    backgroundColor: '#ffffff',
    borderBottomWidth: 1,
    borderBottomColor: '#e5e7eb',
  },
  moduleTab: {
    flex: 1,
    alignItems: 'center',
    paddingVertical: 10,
    borderRadius: 8,
    marginHorizontal: 4,
    backgroundColor: '#f1f5f9',
  },
  moduleTabActive: {
    backgroundColor: '#dbeafe',
  },
  moduleTabText: {
    color: '#475569',
    fontWeight: '600',
  },
  moduleTabTextActive: {
    color: '#1d4ed8',
  },
  apiRoot: {
    flex: 1,
  },
  apiMenu: {
    paddingVertical: 9,
    paddingHorizontal: 8,
    backgroundColor: '#ffffff',
    borderBottomWidth: 1,
    borderBottomColor: '#e5e7eb',
  },
  apiMenuButton: {
    paddingHorizontal: 12,
    paddingVertical: 9,
    marginHorizontal: 4,
    borderRadius: 18,
    backgroundColor: '#f1f5f9',
  },
  apiMenuButtonActive: {
    backgroundColor: '#2563eb',
  },
  apiMenuText: {
    color: '#334155',
    fontSize: 12,
    fontWeight: '600',
  },
  apiMenuTextActive: {
    color: '#ffffff',
  },
  apiDemoContainer: {
    flex: 1,
    padding: 14,
  },
  apiPanel: {
    flex: 1,
    backgroundColor: '#ffffff',
    padding: 14,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: '#e5e7eb',
  },
  apiCentered: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
  },
  apiListContent: {
    paddingBottom: 24,
  },
  apiListRow: {
    paddingVertical: 11,
  },
  apiItemTitle: {
    color: '#111827',
    fontWeight: '600',
    marginBottom: 4,
  },
  separator: {
    height: 1,
    backgroundColor: '#e5e7eb',
  },
  mutedText: {
    color: '#64748b',
    marginTop: 4,
  },
  errorText: {
    color: '#dc2626',
    marginVertical: 8,
  },
  successText: {
    color: '#15803d',
    marginTop: 3,
  },
  subHeading: {
    fontSize: 15,
    fontWeight: 'bold',
    marginTop: 12,
    marginBottom: 6,
    color: '#334155',
  },
  listLine: {
    paddingVertical: 5,
    color: '#334155',
  },
  inlineLoader: {
    marginVertical: 10,
  },
  screen: {
    padding: 20,
    paddingTop: 55,
    backgroundColor: '#f8fafc',
  },
  appTitle: {
    fontSize: 23,
    fontWeight: 'bold',
    marginBottom: 20,
    color: '#111827',
  },
  sectionTitle: {
    fontSize: 17,
    fontWeight: 'bold',
    marginTop: 18,
    marginBottom: 8,
    color: '#1f2937',
  },
  card: {
    backgroundColor: '#ffffff',
    padding: 15,
    marginBottom: 12,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: '#e5e7eb',
  },
  heading: {
    fontSize: 17,
    fontWeight: 'bold',
    marginBottom: 10,
    color: '#222222',
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginVertical: 6,
  },
  smallButton: {
    backgroundColor: '#e2e8f0',
    padding: 10,
    borderRadius: 8,
    marginTop: 8,
  },
  counterText: {
    fontSize: 24,
  },
  deleteText: {
    color: 'red',
  },
  myButton: {
    padding: 12,
    borderRadius: 8,
    alignSelf: 'flex-start',
    marginVertical: 5,
  },
  whiteText: {
    color: 'white',
    textAlign: 'center',
  },
  input: {
    borderWidth: 1,
    borderColor: '#cccccc',
    padding: 10,
    borderRadius: 8,
    marginVertical: 10,
    color: '#111827',
  },
  loadingBox: {
    padding: 20,
    alignItems: 'center',
  },
  genderButton: {
    padding: 9,
    borderRadius: 7,
    backgroundColor: '#e2e8f0',
  },
  genderButtonSelected: {
    backgroundColor: '#bfdbfe',
    borderWidth: 1,
    borderColor: '#2563eb',
  },
  appButton: {
    borderWidth: 1,
    borderRadius: 8,
    alignSelf: 'flex-start',
    marginVertical: 5,
  },
  buttonContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  iconWrapper: {
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 7,
  },
  disabled: {
    opacity: 0.5,
  },
  errorBox: {
    backgroundColor: '#fee2e2',
    padding: 20,
    alignItems: 'center',
    borderRadius: 10,
  },
  retryText: {
    color: '#2563eb',
  },
  fullScreenLoading: {
    minHeight: 120,
    justifyContent: 'center',
    alignItems: 'center',
  },
  listItem: {
    marginVertical: 4,
  },
  bookCard: {
    padding: 15,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: '#dddddd',
    backgroundColor: '#ffffff',
    marginVertical: 8,
  },
  bookCover: {
    width: 80,
    height: 100,
    backgroundColor: '#e2e8f0',
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 8,
  },
  bookCoverText: {
    fontSize: 35,
  },
  bookTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 5,
  },
});
