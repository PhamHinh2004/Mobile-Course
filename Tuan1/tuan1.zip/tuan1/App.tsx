import React, {
  createContext,
  useContext,
  useState,
} from 'react';
import type { ComponentType, ReactNode } from 'react';
import {
  ActivityIndicator,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';

// ============================================================
// DATA + TYPES (data.ts được gộp vào cùng file để dễ thực hành)
// ============================================================

export interface Todo {
  id: string;
  title: string;
}

export interface Book {
  id: string;
  title: string;
  author: string;
  price: number;
  cover: string;
}

export interface Member {
  name: string;
  age: number;
  isAdmin: boolean;
}

export interface Order {
  id: string;
  date: string;
  total: number;
}

export const member: Member = {
  name: 'Nguyen Van A',
  age: 22,
  isAdmin: true,
};

export const initialTodos: Todo[] = [
  { id: '1', title: 'Learn TypeScript' },
  { id: '2', title: 'Learn React Native' },
];

export const books: Book[] = [
  {
    id: '1',
    title: 'Clean Code',
    author: 'Robert C. Martin',
    price: 250000,
    cover: '📘',
  },
  {
    id: '2',
    title: 'The Pragmatic Programmer',
    author: 'Andrew Hunt',
    price: 300000,
    cover: '📕',
  },
  {
    id: '3',
    title: 'Design Patterns',
    author: 'Erich Gamma',
    price: 350000,
    cover: '📗',
  },
];

export const orders: Order[] = [
  { id: 'ORD001', date: '10/11/2026', total: 250000 },
  { id: 'ORD002', date: '11/11/2026', total: 300000 },
];

// ============================================================
// BÀI 1 - UserCard: interface, primitive types, Props
// ============================================================

interface UserCardProps {
  name: string;
  age: number;
  isAdmin: boolean;
}

export function UserCard({ name, age, isAdmin }: UserCardProps) {
  return (
    <View style={styles.card}>
      <Text>Họ tên: {name}</Text>
      <Text>Tuổi: {age}</Text>
      <Text style={{ color: isAdmin ? 'green' : 'blue' }}>
        {isAdmin ? 'Quản trị viên' : 'Thành viên'}
      </Text>
    </View>
  );
}

// ============================================================
// BÀI 2 - Counter: useState, Type Inference
// ============================================================

export function Counter() {
  // TypeScript tự suy luận count có kiểu number.
  const [count, setCount] = useState(0);

  // Cách khai báo tường minh cũng hợp lệ:
  // const [count, setCount] = useState<number>(0);

  const increase = () => setCount(previous => previous + 1);
  const decrease = () => setCount(previous => Math.max(0, previous - 1));

  return (
    <View style={styles.card}>
      <Text style={styles.counterText}>Count: {count}</Text>
      <View style={styles.row}>
        <Pressable style={styles.smallButton} onPress={increase}>
          <Text>+</Text>
        </Pressable>
        <Pressable style={styles.smallButton} onPress={decrease}>
          <Text>-</Text>
        </Pressable>
      </View>
    </View>
  );
}

// ============================================================
// BÀI 3 - TodoList: Todo[], object type, map, filter
// ============================================================

export function TodoList() {
  const [todos, setTodos] = useState<Todo[]>(initialTodos);

  const addTodo = () => {
    const newTodo: Todo = {
      id: Date.now().toString(),
      title: `Task ${todos.length + 1}`,
    };
    setTodos(previous => [...previous, newTodo]);
  };

  const deleteTodo = (id: string) => {
    setTodos(previous => previous.filter(item => item.id !== id));
  };

  return (
    <View style={styles.card}>
      <Text style={styles.heading}>Todo List</Text>
      {todos.map(item => (
        <View key={item.id} style={styles.row}>
          <Text>{item.title}</Text>
          <Pressable onPress={() => deleteTodo(item.id)}>
            <Text style={styles.deleteText}>Delete</Text>
          </Pressable>
        </View>
      ))}
      <Pressable style={styles.smallButton} onPress={addTodo}>
        <Text>Add Todo</Text>
      </Pressable>
    </View>
  );
}

// ============================================================
// BÀI 4 - MyButton: optional property, callback function
// ============================================================

interface MyButtonProps {
  label: string;
  onPress: () => void;
  color?: string;
}

export function MyButton({
  label,
  onPress,
  color = 'blue',
}: MyButtonProps) {
  return (
    <Pressable
      onPress={onPress}
      style={[styles.myButton, { backgroundColor: color }]}
    >
      <Text style={styles.whiteText}>{label}</Text>
    </Pressable>
  );
}

// ============================================================
// BÀI 5 - LiveInput: TextInput onChangeText nhận string
// ============================================================

export function LiveInput() {
  const [value, setValue] = useState<string>('');

  const handleChange = (text: string) => {
    setValue(text);
  };

  return (
    <View style={styles.card}>
      <Text>Nhập nội dung:</Text>
      <TextInput
        style={styles.input}
        value={value}
        onChangeText={handleChange}
        placeholder="Nhập text..."
      />
      <Text>Số ký tự: {value.length}</Text>
    </View>
  );
}

// ============================================================
// BÀI 6 - LoadingContainer: ReactNode, children
// ============================================================

interface LoadingContainerProps {
  isLoading: boolean;
  children: ReactNode;
}

export function LoadingContainer({
  isLoading,
  children,
}: LoadingContainerProps) {
  if (isLoading) {
    return (
      <View style={styles.loadingBox}>
        <ActivityIndicator size="large" color="blue" />
      </View>
    );
  }

  return <View>{children}</View>;
}

// ============================================================
// BÀI 7 - GenderSelector: Union Types
// ============================================================

type Gender = 'male' | 'female' | 'other';

export function GenderSelector() {
  const [gender, setGender] = useState<Gender>('male');

  const options: Gender[] = ['male', 'female', 'other'];

  return (
    <View style={styles.card}>
      <Text style={styles.heading}>Gender: {gender}</Text>
      <View style={styles.row}>
        {options.map(option => (
          <Pressable
            key={option}
            onPress={() => setGender(option)}
            style={[
              styles.genderButton,
              gender === option && styles.genderButtonSelected,
            ]}
          >
            <Text>{option}</Text>
          </Pressable>
        ))}
      </View>
    </View>
  );
}

// ============================================================
// BÀI 8 - AppButton: Variant Props + Record
// ============================================================

type ButtonVariant = 'primary' | 'secondary' | 'outline' | 'danger';
type ButtonSize = 'small' | 'medium' | 'large';

interface AppButtonProps {
  title: string;
  variant?: ButtonVariant;
  size?: ButtonSize;
  onPress: () => void;
  disabled?: boolean;
  loading?: boolean;
  icon?: ReactNode;
}

const variantStyles: Record<
  ButtonVariant,
  { backgroundColor: string; borderColor: string; textColor: string }
> = {
  primary: {
    backgroundColor: '#2563eb',
    borderColor: '#2563eb',
    textColor: '#ffffff',
  },
  secondary: {
    backgroundColor: '#64748b',
    borderColor: '#64748b',
    textColor: '#ffffff',
  },
  outline: {
    backgroundColor: 'transparent',
    borderColor: '#2563eb',
    textColor: '#2563eb',
  },
  danger: {
    backgroundColor: '#dc2626',
    borderColor: '#dc2626',
    textColor: '#ffffff',
  },
};

const sizeStyles: Record<
  ButtonSize,
  { paddingVertical: number; paddingHorizontal: number; fontSize: number }
> = {
  small: { paddingVertical: 6, paddingHorizontal: 10, fontSize: 12 },
  medium: { paddingVertical: 10, paddingHorizontal: 16, fontSize: 14 },
  large: { paddingVertical: 14, paddingHorizontal: 20, fontSize: 16 },
};

export function AppButton({
  title,
  variant = 'primary',
  size = 'medium',
  onPress,
  disabled = false,
  loading = false,
  icon,
}: AppButtonProps) {
  const currentVariant = variantStyles[variant];
  const currentSize = sizeStyles[size];
  const isDisabled = disabled || loading;

  return (
    <Pressable
      onPress={onPress}
      disabled={isDisabled}
      style={[
        styles.appButton,
        {
          backgroundColor: currentVariant.backgroundColor,
          borderColor: currentVariant.borderColor,
          paddingVertical: currentSize.paddingVertical,
          paddingHorizontal: currentSize.paddingHorizontal,
        },
        isDisabled && styles.disabled,
      ]}
    >
      <View style={styles.buttonContent}>
        {loading ? (
          <ActivityIndicator color={currentVariant.textColor} />
        ) : (
          <>
            {icon ? <View style={styles.iconWrapper}>{icon}</View> : null}
            <Text
              style={{
                color: currentVariant.textColor,
                fontSize: currentSize.fontSize,
              }}
            >
              {title}
            </Text>
          </>
        )}
      </View>
    </Pressable>
  );
}

// ============================================================
// BÀI 9 - HOC: Generic + ComponentType + Intersection Type
// ============================================================

interface ErrorViewProps {
  message?: string;
  onRetry: () => void;
}

function ErrorView({ message, onRetry }: ErrorViewProps) {
  return (
    <View style={styles.errorBox}>
      <Text>{message ?? 'Có lỗi xảy ra!'}</Text>
      <Pressable onPress={onRetry} style={styles.smallButton}>
        <Text style={styles.retryText}>Thử lại</Text>
      </Pressable>
    </View>
  );
}

interface WithLoadingProps {
  isLoading: boolean;
  isError: boolean;
  errorMessage?: string;
  onRetry: () => void;
}

export function withLoadingState<P extends object>(
  WrappedComponent: ComponentType<P>,
) {
  type Props = P & WithLoadingProps;

  function WithLoadingState(props: Props) {
    const {
      isLoading,
      isError,
      errorMessage,
      onRetry,
      ...restProps
    } = props;

    if (isLoading) {
      return (
        <View style={styles.fullScreenLoading}>
          <ActivityIndicator size="large" color="blue" />
        </View>
      );
    }

    if (isError) {
      return <ErrorView message={errorMessage} onRetry={onRetry} />;
    }

    return <WrappedComponent {...(restProps as P)} />;
  }

  return WithLoadingState;
}

interface BookListScreenProps {
  books: Book[];
}

function BookListScreen({ books: bookItems }: BookListScreenProps) {
  return (
    <View style={styles.card}>
      <Text style={styles.heading}>Danh sách sách</Text>
      {bookItems.map(book => (
        <Text key={book.id} style={styles.listItem}>
          {book.title} - {book.price.toLocaleString('vi-VN')}đ
        </Text>
      ))}
    </View>
  );
}

interface OrderHistoryScreenProps {
  orders: Order[];
}

function OrderHistoryScreen({ orders: orderItems }: OrderHistoryScreenProps) {
  return (
    <View style={styles.card}>
      <Text style={styles.heading}>Lịch sử đơn hàng</Text>
      {orderItems.map(order => (
        <Text key={order.id} style={styles.listItem}>
          {order.id} - {order.total.toLocaleString('vi-VN')}đ
        </Text>
      ))}
    </View>
  );
}

export const BookListWithLoading = withLoadingState(BookListScreen);
export const OrderHistoryWithLoading = withLoadingState(OrderHistoryScreen);

// ============================================================
// BÀI 10 - Compound Component: Context + useContext
// ============================================================

interface BookCardContextValue {
  book: Book;
  isFavorite: boolean;
  toggleFavorite: () => void;
}

const BookCardContext = createContext<BookCardContextValue | null>(null);

function useBookCard() {
  const context = useContext(BookCardContext);

  if (context === null) {
    throw new Error('BookCard components phải nằm bên trong BookCard.');
  }

  return context;
}

interface BookCardProps {
  book: Book;
  children: ReactNode;
}

function BookCardRoot({ book, children }: BookCardProps) {
  const [isFavorite, setIsFavorite] = useState(false);

  const toggleFavorite = () => {
    setIsFavorite(previous => !previous);
  };

  const contextValue: BookCardContextValue = {
    book,
    isFavorite,
    toggleFavorite,
  };

  return (
    <BookCardContext.Provider value={contextValue}>
      <View style={styles.bookCard}>{children}</View>
    </BookCardContext.Provider>
  );
}

function BookCover() {
  const { book } = useBookCard();

  return (
    <View style={styles.bookCover}>
      <Text style={styles.bookCoverText}>{book.cover}</Text>
    </View>
  );
}

function BookTitle() {
  const { book } = useBookCard();
  return <Text style={styles.bookTitle}>{book.title}</Text>;
}

function BookPrice() {
  const { book } = useBookCard();
  return <Text>Giá: {book.price.toLocaleString('vi-VN')}đ</Text>;
}

function FavoriteButton() {
  const { isFavorite, toggleFavorite } = useBookCard();

  return (
    <Pressable onPress={toggleFavorite} style={styles.smallButton}>
      <Text>{isFavorite ? '❤️ Đã yêu thích' : '♡ Yêu thích'}</Text>
    </Pressable>
  );
}

export const BookCard = Object.assign(BookCardRoot, {
  Cover: BookCover,
  Title: BookTitle,
  Price: BookPrice,
  FavoriteButton,
});

// ============================================================
// APP - Chạy thử toàn bộ 10 bài tập
// ============================================================

export default function App() {
  return (
    <ScrollView contentContainerStyle={styles.screen}>
      <Text style={styles.appTitle}>BookStore - TypeScript Practice</Text>

      <Text style={styles.sectionTitle}>Bài 1: UserCard</Text>
      <UserCard {...member} />

      <Text style={styles.sectionTitle}>Bài 2: Counter</Text>
      <Counter />

      <Text style={styles.sectionTitle}>Bài 3: TodoList</Text>
      <TodoList />

      <Text style={styles.sectionTitle}>Bài 4: MyButton</Text>
      <MyButton
        label="Thêm vào giỏ hàng"
        color="green"
        onPress={() => console.log('Added to cart')}
      />

      <Text style={styles.sectionTitle}>Bài 5: LiveInput</Text>
      <LiveInput />

      <Text style={styles.sectionTitle}>Bài 6: LoadingContainer</Text>
      <LoadingContainer isLoading={false}>
        <Text>Danh sách sách BookStore</Text>
        <Text>Clean Code</Text>
        <Text>Design Patterns</Text>
      </LoadingContainer>

      <Text style={styles.sectionTitle}>Bài 7: GenderSelector</Text>
      <GenderSelector />

      <Text style={styles.sectionTitle}>Bài 8: AppButton</Text>
      <AppButton
        title="Thêm vào giỏ hàng"
        variant="primary"
        onPress={() => console.log('Add cart')}
        icon={<Text>🛒</Text>}
      />
      <AppButton
        title="Xem chi tiết"
        variant="outline"
        onPress={() => console.log('View detail')}
      />
      <AppButton
        title="Xóa sách"
        variant="danger"
        onPress={() => console.log('Delete book')}
      />

      <Text style={styles.sectionTitle}>Bài 9: HOC - Book List</Text>
      <BookListWithLoading
        books={books}
        isLoading={false}
        isError={false}
        onRetry={() => console.log('Retry books')}
      />

      <Text style={styles.sectionTitle}>Bài 9: HOC - Order History</Text>
      <OrderHistoryWithLoading
        orders={orders}
        isLoading={false}
        isError={false}
        onRetry={() => console.log('Retry orders')}
      />

      <Text style={styles.sectionTitle}>Bài 10: Compound Component</Text>
      {books.map(book => (
        <BookCard key={book.id} book={book}>
          <BookCard.Cover />
          <BookCard.Title />
          <BookCard.Price />
          <BookCard.FavoriteButton />
        </BookCard>
      ))}
    </ScrollView>
  );
}

// ============================================================
// STYLES
// ============================================================

const styles = StyleSheet.create({
  screen: {
    padding: 20,
    paddingTop: 55,
    backgroundColor: '#f8fafc',
  },
  appTitle: {
    fontSize: 23,
    fontWeight: 'bold',
    marginBottom: 20,
    color: '#111827',
  },
  sectionTitle: {
    fontSize: 17,
    fontWeight: 'bold',
    marginTop: 18,
    marginBottom: 8,
    color: '#1f2937',
  },
  card: {
    backgroundColor: '#ffffff',
    padding: 15,
    marginBottom: 12,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: '#e5e7eb',
  },
  heading: {
    fontSize: 17,
    fontWeight: 'bold',
    marginBottom: 10,
    color: '#222222',
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginVertical: 6,
  },
  smallButton: {
    backgroundColor: '#e2e8f0',
    padding: 10,
    borderRadius: 8,
    marginTop: 8,
  },
  counterText: {
    fontSize: 24,
  },
  deleteText: {
    color: 'red',
  },
  myButton: {
    padding: 12,
    borderRadius: 8,
    alignSelf: 'flex-start',
    marginVertical: 5,
  },
  whiteText: {
    color: 'white',
    textAlign: 'center',
  },
  input: {
    borderWidth: 1,
    borderColor: '#cccccc',
    padding: 10,
    borderRadius: 8,
    marginVertical: 10,
    color: '#111827',
  },
  loadingBox: {
    padding: 20,
    alignItems: 'center',
  },
  genderButton: {
    padding: 9,
    borderRadius: 7,
    backgroundColor: '#e2e8f0',
  },
  genderButtonSelected: {
    backgroundColor: '#bfdbfe',
    borderWidth: 1,
    borderColor: '#2563eb',
  },
  appButton: {
    borderWidth: 1,
    borderRadius: 8,
    alignSelf: 'flex-start',
    marginVertical: 5,
  },
  buttonContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  iconWrapper: {
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 7,
  },
  disabled: {
    opacity: 0.5,
  },
  errorBox: {
    backgroundColor: '#fee2e2',
    padding: 20,
    alignItems: 'center',
    borderRadius: 10,
  },
  retryText: {
    color: '#2563eb',
  },
  fullScreenLoading: {
    minHeight: 120,
    justifyContent: 'center',
    alignItems: 'center',
  },
  listItem: {
    marginVertical: 4,
  },
  bookCard: {
    padding: 15,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: '#dddddd',
    backgroundColor: '#ffffff',
    marginVertical: 8,
  },
  bookCover: {
    width: 80,
    height: 100,
    backgroundColor: '#e2e8f0',
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 8,
  },
  bookCoverText: {
    fontSize: 35,
  },
  bookTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 5,
  },
});
